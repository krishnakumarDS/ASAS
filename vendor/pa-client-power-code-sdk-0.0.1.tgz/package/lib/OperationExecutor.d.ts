/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IOperationResult } from '@pa-client/power-data-runtime/lib/powerDataRuntime/powerDataRuntime.Types';
/**
 * Executes operations using the plugin.
 */
export declare class OperationExecutor {
    /**
     * Executes an operation using the plugin.
     * @param operationName The name of the operation.
     * @param action The action to perform.
     * @param params The parameters for the operation.
     * @returns A promise resolving to the operation result.
     */
    execute<T = string>(operationName: string, action: string, params: unknown[]): Promise<IOperationResult<T>>;
}
//# sourceMappingURL=OperationExecutor.d.ts.map