/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import type { Metric } from '@pa-client/powerapps-runtime-types/lib/Metrics/Metrics.types';
export interface Logger {
    logMetric?: (value: Metric) => void;
}
//# sourceMappingURL=Logger.types.d.ts.map