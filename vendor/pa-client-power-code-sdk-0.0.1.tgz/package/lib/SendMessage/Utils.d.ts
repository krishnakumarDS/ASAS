/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
/**
 * Returns an RFC 4122 Compliant UUID; i.e. a GUID.
 */
export declare function generate128BitUUID(): string;
//# sourceMappingURL=Utils.d.ts.map