/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare class SendMessageOperation {
    resultPromise: Promise<string>;
    sendUpdate: (update: string) => void;
    /**
     * When completed is false onMessageReceived and sendUpdate will be visible.
     * When completed is true then these are hidden.
     */
    completed: boolean;
    onMessageReceived: ((message: string) => void) | undefined;
    constructor(resultPromise: Promise<string>, sendUpdate: (update: string) => void);
}
//# sourceMappingURL=SendMessageOperation.d.ts.map