/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { ErrorCodes } from './codes';
export declare const UnknownErrorMessage = "An unknown error occurred";
export declare const ErrorMessages: {
    [key in ErrorCodes]?: string;
};
export declare enum DataOperationErrorMessages {
    CreateFailed = "Create operation failure",
    DeleteFailed = "Delete operation failure",
    ExecuteFailed = "Execute operation failure",
    InvalidOperationParameters = "Invalid operation parameters",
    InvalidRequest = "Invalid request",
    InvalidResponse = "Invalid response format",
    MissingConnectorOperation = "Connector operation is required",
    MissingDataverseRequest = "Dataverse request is required",
    MissingOperationName = "Operation name is required",
    MissingRequestBody = "Request body is required",
    RetrieveFailed = "Retrieve operation failure",
    RetrieveMultipleFailed = "Retrieve multiple records operation failure",
    UpdateFailed = "Update operation failure"
}
//# sourceMappingURL=messages.d.ts.map