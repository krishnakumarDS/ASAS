/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IOperationResult } from '../powerDataRuntime.Types';
import { PowerDataRuntimeError, PowerDataRuntimeHttpError } from './types';
/**
 * Retrieves the error message from an error object.
 * @param error - The error to handle, which can be an instance of Error or IOperationResult.
 * @returns The error message if applicable, or throws the error if it's a PowerDataRuntimeError.
 */
export declare function getErrorMessage(error: Error | IOperationResult<unknown> | object | PowerDataRuntimeHttpError | string | unknown | unknown[]): string;
/**
 * Handles operation errors and creates an error OperationResult
 * @param error - The error object or OperationResult
 * @param friendlyMessage - A friendly message to include in the error
 */
export declare function createErrorResponse<T>(error: Error | PowerDataRuntimeError | IOperationResult<T> | unknown, friendlyMessage: string): IOperationResult<T>;
/**
 * Parses an error from the HTTP plugin and returns a PowerDataRuntimeHttpError object.
 * @param error - The error to parse, which should be an array with a nested array.
 * @returns A PowerDataRuntimeHttpError object containing the message and response.
 */
export declare function parseHttpPluginError(error: unknown): PowerDataRuntimeHttpError;
//# sourceMappingURL=util.d.ts.map