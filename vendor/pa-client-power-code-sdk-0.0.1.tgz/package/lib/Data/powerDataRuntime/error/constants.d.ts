/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
export declare enum HeaderNames {
    /**
     * The name of the header used to specify the request ID.
     */
    RequestId = "x-ms-client-request-id"
}
/**
 * Enum for DataverseDataOperation operation names.
 */
export declare enum DataverseOperationName {
    CreateRecord = "dataverseDataOperation.createRecordAsync",
    UpdateRecord = "dataverseDataOperation.updateRecordAsync",
    DeleteRecord = "dataverseDataOperation.deleteRecordAsync",
    RetrieveRecord = "dataverseDataOperation.retrieveRecordAsync",
    RetrieveMultipleRecords = "dataverseDataOperation.retrieveMultipleRecordsAsync"
}
/**
 * Enum for ConnectorDataOperation operation names.
 */
export declare enum ConnectorOperationName {
    CreateRecord = "connectorDataOperation.createRecordAsync",
    UpdateRecord = "connectorDataOperation.updateRecordAsync",
    DeleteRecord = "connectorDataOperation.deleteRecordAsync",
    RetrieveRecord = "connectorDataOperation.retrieveRecordAsync",
    RetrieveMultipleRecords = "connectorDataOperation.retrieveMultipleRecordsAsync"
}
//# sourceMappingURL=constants.d.ts.map