/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IMetadataOperations, IPowerDataSourcesInfoProvider, IXrmContext } from './common/types';
import { IClientConfig } from './common/types';
import { IDataOperations, IPowerDataRuntime, IPowerOperationExecutor } from './powerDataRuntime.Types';
/**
 * Interface for PowerDataRuntime initialization parameters
 */
export interface IPowerDataRuntimeInitParams {
    powerDataSourcesInfoProvider: IPowerDataSourcesInfoProvider;
    powerOperationExecutor: IPowerOperationExecutor;
    xrm: IXrmContext;
    clientConfig?: IClientConfig;
}
/**
 * PowerDataRuntime provides a unified interface for data and metadata operations
 * in the Power runtime environment.
 */
export declare class PowerDataRuntime implements IPowerDataRuntime {
    private readonly _clientProvider;
    private readonly _dataSourceService;
    private readonly _xrm;
    private _dataOperations?;
    private _metadataOperations?;
    private _isInitialized;
    /**
     * Creates a new instance of PowerDataRuntime
     * @param params - Initialization parameters
     * @throws DataRuntimeError if initialization fails
     */
    constructor(params: IPowerDataRuntimeInitParams);
    /**
     * Gets the Data operations interface
     * @throws PowerDataRuntimeError if operations are not initialized
     */
    get Data(): IDataOperations;
    /**
     * Gets the Metadata operations interface
     * @throws PowerDataRuntimeError if operations are not initialized
     */
    get Metadata(): IMetadataOperations;
    /**
     * Validates initialization parameters
     * @param params - Parameters to validate
     * @throws PowerDataRuntimeError if validation fails
     */
    private _validateInitParams;
    /**
     * Ensures the PowerDataRuntime is initialized
     * @throws PowerDataRuntimeError if not initialized
     */
    private _ensureInitialized;
    /**
     * Initializes the PowerDataRuntime components
     * @throws PowerDataRuntimeError if initialization fails
     */
    private _initialize;
    /**
     * Creates a new instance of DataOperations
     */
    private _createDataOperations;
    /**
     * Creates a new instance of MetadataOperations
     */
    private _createMetadataOperations;
}
//# sourceMappingURL=powerDataRuntime.d.ts.map