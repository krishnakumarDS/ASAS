/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IPowerDataSourcesInfoProvider } from './common/types';
import { DataSourcesInfo } from './powerDataRuntime.Types';
/**
 * Singleton provider for managing data sources information.
 */
declare class PowerDataSourcesInfoProvider implements IPowerDataSourcesInfoProvider {
    private static instance;
    private dataSourcesInfo;
    /**
     * Private constructor to enforce the singleton pattern.
     * @param dataSourcesInfo The data sources information to initialize the provider with.
     */
    private constructor();
    /**
     * Retrieves the singleton instance of PowerDataSourcesInfoProvider.
     * If the instance does not exist, it initializes it with the provided data sources info.
     *
     * @param dataSourcesInfo Optional parameter to initialize the instance if it doesn't exist.
     * @returns The singleton instance of PowerDataSourcesInfoProvider.
     * @throws Error if the instance is not initialized and no dataSourcesInfo is provided.
     */
    static getInstance(dataSourcesInfo?: DataSourcesInfo): PowerDataSourcesInfoProvider;
    /**
     * Retrieves the data sources information.
     *
     * @returns A promise resolving to the data sources information.
     */
    getDataSourcesInfo(): Promise<DataSourcesInfo>;
}
export default PowerDataSourcesInfoProvider;
//# sourceMappingURL=powerDataSourcesInfoProvider.d.ts.map