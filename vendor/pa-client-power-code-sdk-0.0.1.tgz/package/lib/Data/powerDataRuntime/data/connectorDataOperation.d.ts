/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IConnectionReference, IRuntimeClientProvider } from '../common/types';
import { RuntimeDataSourceService } from '../metadata/runtimeDataSourceService';
import { IDataOperation, IOperationResult } from '../powerDataRuntime.Types';
/**
 * Type for connection references mapping
 */
export type ConnectionReferences = Record<string, IConnectionReference>;
/**
 * Interface for connector operation configuration
 */
export interface IConnectorOperationConfig {
    tableName: string;
    apiId: string;
    runtimeUrl: string;
    connectionName: string;
    datasetName?: string;
    tableId: string;
    version?: string;
    datasetNameOverride?: string;
}
/**
 * ConnectorDataOperation provides functionality for performing CRUD operations
 * against connector data sources using the Runtime Data Client.
 */
export declare class ConnectorDataOperation {
    private readonly _clientProvider;
    private readonly _connectionsService;
    private _databaseReferences;
    private _connectionReferences;
    constructor(clientProvider: IRuntimeClientProvider, connectionsService: RuntimeDataSourceService);
    /**
     * Creates a new record in the specified table
     */
    createRecordAsync<TRequest, TResponse>(tableName: string, data: TRequest): Promise<IOperationResult<TResponse>>;
    /**
     * Updates an existing record in the specified table
     */
    updateRecordAsync<TRequest, TResponse>(tableName: string, id: string, data: TRequest): Promise<IOperationResult<TResponse>>;
    /**
     * Deletes a record from the specified table
     */
    deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>>;
    /**
     * Retrieves a single record from the specified table
     */
    retrieveRecordAsync<TResponse>(tableName: string, id: string, options: string): Promise<IOperationResult<TResponse>>;
    /**
     * Retrieves multiple records from the specified table
     */
    retrieveMultipleRecordsAsync<TResponse>(tableName: string, options: string): Promise<IOperationResult<TResponse[]>>;
    /**
     * Executes a custom operation on the data source
     */
    executeAsync<TRequest, TResponse>(operation: IDataOperation<TRequest>): Promise<IOperationResult<TResponse>>;
    /**
     * Determines the appropriate HTTP method for a request
     * @param requestUrl - The URL for the request
     * @param dataSourceInfo - The data source information
     * @param operation - The operation name
     * @returns The HTTP method to use
     */
    private _getHttpMethod;
    /**
     * Builds the operation body parameters
     */
    private _buildOperationBody;
    /**
     * Builds operation body parameters from the operation and data source info
     */
    private _buildOperationBodyParam;
    /**
     * Builds the operation header for a given data operation if required.
     *
     * @template TRequest - The type of the request payload for the data operation.
     * @param dataOperationRequest - The data operation containing details about the connector operation.
     * @param tableName - The name of the table associated with the data operation.
     * @returns A promise that resolves to the operation header as a string if a header parameter is required,
     *          or `undefined` if no header parameter is needed.
     */
    private _buildOperationHeader;
    /**
     * Builds the operation header parameters as a JSON string for a given data operation.
     *
     * @template TRequest - The type of the request object for the data operation.
     * @param dataOperationRequest - The data operation containing connector operation details and parameters.
     * @param tableName - The name of the table associated with the data operation.
     * @returns A promise that resolves to a JSON string representing the header parameters,
     *          or `undefined` if no `header` parameters are available.
     */
    private _buildOperationHeaderParam;
    /**
     * Constructs the request URL for table operations
     * @param tableName - The name of the table
     * @param connectionReference - The connection reference
     * @param options - Optional URL parameters
     * @param encodeOptions - Whether to encode the options
     * @returns The constructed URL
     */
    private _buildTableUrl;
    /**
     * Builds the operation URL
     */
    private _buildOperationUrl;
    /**
     * Gets the connection references
     */
    private _getConnectionReferencesAsync;
    /**
     * Gets the database references
     */
    private _getDatabaseReferencesAsync;
    /**
     * Gets the metadata client instance
     */
    private _getMetadataClient;
    /**
     * Gets the connection reference for a table
     */
    private _getConnectionReference;
    /**
     * Gets both the data client and connection reference
     */
    private _getClientsAndConnection;
    /**
     * Builds the URL for shared SQL operations
     */
    private _buildSharedSqlOperationUrl;
    /**
     * Builds the URL for standard operations
     */
    private _buildStandardOperationUrl;
    /**
     * Normalizes the parameter name by replacing hyphens with underscores and performs case-insensitive matching
     */
    private _getNormalizedParamValue;
    /**
     * Processes operation parameters into path and query parameters
     */
    private _processParameters;
    /**
     * Gets the operation configuration
     */
    private _getOperationConfig;
    /**
     * Initializes the clients
     */
    private _getReferences;
    /**
     * Validates constructor parameters
     */
    private _validateConstructorParams;
    /**
     * Constructs the final URL
     */
    private _constructUrl;
}
//# sourceMappingURL=connectorDataOperation.d.ts.map