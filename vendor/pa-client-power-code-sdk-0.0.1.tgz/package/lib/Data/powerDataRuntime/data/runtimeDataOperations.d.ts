/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IDataOperation, IDataOperations, IOperationOptions, IOperationResult } from '../powerDataRuntime.Types';
import { DataverseDataOperation } from './dataverseDataOperation';
import { ConnectorDataOperation } from './connectorDataOperation';
import { RuntimeDataSourceService } from '../metadata/runtimeDataSourceService';
/**
 * RuntimeDataOperations provides a unified interface for performing data operations
 * across different data sources.
 */
export declare class RuntimeDataOperations implements IDataOperations {
    private readonly _dataverseOperation;
    private readonly _connectorOperation;
    private readonly _connectionsService;
    constructor(_dataverseOperation: DataverseDataOperation, _connectorOperation: ConnectorDataOperation, _connectionsService: RuntimeDataSourceService);
    /**
     * Creates a new record in the specified data source.
     * @param tableName - The name of the table.
     * @param data - The record data to create.
     * @returns A promise that resolves to the operation result.
     * @throws DataOperationError if the operation fails.
     */
    createRecordAsync<TRequest, TResponse>(tableName: string, data: TRequest): Promise<IOperationResult<TResponse>>;
    /**
     * Updates an existing record in the specified data source.
     * @param tableName - The name of the table.
     * @param id - The ID of the record to update.
     * @param data - The updated record data.
     * @returns A promise that resolves to the operation result.
     * @throws DataOperationError if the operation fails.
     */
    updateRecordAsync<TRequest, TResponse>(tableName: string, id: string, data: TRequest): Promise<IOperationResult<TResponse>>;
    /**
     * Deletes a record from the specified data source.
     * @param tableName - The name of the table.
     * @param id - The ID of the record to delete.
     * @returns A promise that resolves to the operation result.
     * @throws DataOperationError if the operation fails.
     */
    deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>>;
    /**
     * Retrieves a record from the specified data source.
     * @param tableName - The name of the table.
     * @param id - The ID of the record to retrieve.
     * @param options - Optional operation options.
     * @returns A promise that resolves to the operation result.
     * @throws DataOperationError if the operation fails.
     */
    retrieveRecordAsync<TResponse>(tableName: string, id: string, options?: IOperationOptions): Promise<IOperationResult<TResponse>>;
    /**
     * Retrieves multiple records from the specified data source.
     * @param tableName - The name of the table.
     * @param options - Optional operation options.
     * @returns A promise that resolves to the operation result.
     * @throws DataOperationError if the operation fails.
     */
    retrieveMultipleRecordsAsync<TResponse>(tableName: string, options?: IOperationOptions): Promise<IOperationResult<TResponse[]>>;
    /**
     * Executes a data operation on the specified data source.
     * @param operation - The operation to execute
     * @returns A promise that resolves to the operation result.
     * @throws DataOperationError if the operation fails.
     */
    executeAsync<TRequest, TResponse>(operation: IDataOperation<TRequest>): Promise<IOperationResult<TResponse>>;
    /**
     * Retrieves the appropriate executor based on the data source.
     * @param dataSource - The data source to retrieve the executor for.
     * @returns The corresponding executor instance.
     * @throws DataOperationError if the data source is invalid.
     * // TODO: Add Dataverse support
     */
    private _getExecutor;
    /**
     * Validates the input parameters for data operations.
     * @param params - The parameters to validate.
     * @throws DataOperationError if validation fails.
     */
    private _validateParams;
    /**
     * Converts operation options to a query string format.
     * @param options - The operation options to convert.
     * @returns The formatted query string.
     */
    private _convertOptionsToString;
    /**
     * Validates the operation options.
     * @param options - The operation options to validate.
     * @throws Error if validation fails.
     */
    private _validateOptions;
}
//# sourceMappingURL=runtimeDataOperations.d.ts.map