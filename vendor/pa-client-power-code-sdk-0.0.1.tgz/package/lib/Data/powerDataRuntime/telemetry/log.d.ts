/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */
import { IPowerOperationExecutor } from '../powerDataRuntime.Types';
export declare class Log {
    private readonly _powerOperationExecutor;
    private static _instance;
    private constructor();
    static createInstance(powerOperationExecutor: IPowerOperationExecutor): Log;
    static resetInstance(): void;
    private static _sendMessage;
    static trackEvent(eventName: string, eventData?: object): Promise<void>;
    static trackException(exception: object): Promise<void>;
    static trackMetric(metricName: string, value: number): Promise<void>;
    static startScenario(scenarioName: string): Promise<void>;
    static endScenario(scenarioName: string): Promise<void>;
    static setDefaultProperties(properties: object): Promise<void>;
    private static _getInstance;
}
//# sourceMappingURL=log.d.ts.map