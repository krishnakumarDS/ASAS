/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

module.exports = {
  extends: ['./node_modules/@pa-client/build-scripts/.eslintrc.base.js'],
  rules: {
    'no-external-vars': [
      'error',
      {
        allowedList: [
          'Blob',
          'console*',
          'cordova*',
          'document*',
          'ErrorEvent',
          'Event',
          'HTMLScriptElement',
          'MessageEvent',
          'MessagePort',
          'Performance',
          'PerformanceEntryList',
          'PerformanceNavigationTiming',
          'URLSearchParams',
          'Window',
          'window*',
        ],
      },
    ],
  },
};
