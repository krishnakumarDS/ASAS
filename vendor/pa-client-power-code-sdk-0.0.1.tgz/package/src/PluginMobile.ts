/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  // eslint-disable-next-line @typescript-eslint/prefer-namespace-keyword, @typescript-eslint/no-namespace
  module cordova {
    export function exec(
      success: (data: any) => any,
      fail: (err: any) => any,
      service: string,
      action: string,
      args?: any[]
    ): void;
  }
}

let cordovaOperationsQueue: Array<() => any> = [];

function executePendingCordovaOperations() {
  for (let i = 0; i < cordovaOperationsQueue.length; i++) {
    cordovaOperationsQueue[i]();
  }
  cordovaOperationsQueue = [];
}

export function executePlugin(pluginName: string, pluginAction: string, params: unknown[] = []): void {
  if (typeof cordova !== 'undefined') {
    cordova.exec(
      // eslint-disable-next-line no-empty-function
      () => {},
      // eslint-disable-next-line no-empty-function
      () => {},
      pluginName,
      pluginAction,
      params
    );
  } else {
    cordovaOperationsQueue.push(() => {
      cordova.exec(
        // eslint-disable-next-line no-empty-function
        () => {},
        // eslint-disable-next-line no-empty-function
        () => {},
        pluginName,
        pluginAction,
        params
      );
    });
  }
}

export function executePluginAsync<T = unknown>(
  pluginName: string,
  pluginAction: string,
  params: unknown[] = []
): Promise<T> {
  return new Promise<unknown>((resolve, reject) => {
    if (typeof cordova !== 'undefined') {
      cordova.exec(resolve, reject, pluginName, pluginAction, params);
    } else {
      cordovaOperationsQueue.push(() => {
        cordova.exec(resolve, reject, pluginName, pluginAction, params);
      });
    }
  }) as Promise<T>;
}

export async function initializeMobilePlugins(): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        callLoader(resolve, reject);
      });
    } else {
      callLoader(resolve, reject);
    }
  });
  executePendingCordovaOperations();
}

async function getCordova(successCallback: () => void): Promise<void> {
  if (typeof cordova !== 'undefined') {
    successCallback();
  } else {
    document.addEventListener('deviceready', () => {
      successCallback();
    });
  }
}

export function isMobilePlayer() {
  const searchParams = new URLSearchParams(window.location.search);
  return searchParams.get('loaderType') === 'reactnative';
}

function callLoader(successCallback: () => void, failCallback: () => void) {
  // for ios, cordova script will be injected directly by player
  if (getSearchParam('injectCordova') === 'true' && getSearchParam('platformOS') === 'ios') {
    getCordova(successCallback);
    return;
  }
  const appServerUrl = getSearchParam('appServerUrl');
  const loaderPath = getSearchParam('loader');
  if (appServerUrl !== null && loaderPath !== null) {
    addScript(
      `${appServerUrl}${loaderPath.substring(1)}`,
      () => {
        getCordova(successCallback);
      },
      failCallback
    );
  } else {
    failCallback();
  }
}

function getSearchParam(param: string): string | null {
  const searchParams = new URLSearchParams(window.location.search);
  return searchParams.get(param);
}

function addScript(
  src: string,
  successCallback?: (event: Event) => void,
  failCallback?: (event: ErrorEvent) => void
) {
  const scriptTag = document.createElement('SCRIPT') as HTMLScriptElement;
  scriptTag.setAttribute('crossorigin', 'anonymous');
  scriptTag.type = 'text/javascript';
  scriptTag.async = false;
  if (successCallback) {
    scriptTag.addEventListener('load', successCallback);
  }
  if (failCallback) {
    scriptTag.addEventListener('error', failCallback);
  }
  document.head.appendChild(scriptTag);
  scriptTag.src = src;
}
