/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import type { Logger } from './Logger.types';
import type { SendMessagePlugin } from './SendMessage/MessageReceiver.Types';
import { SendMessage } from './SendMessage/SendMessage';
import type { MessageReceiver } from './SendMessage/MessageReceiver.Types';

let loggerInstance: Logger;

export async function setupLogger(logger: Logger): Promise<void> {
  loggerInstance = logger;

  const sendMessagePlugin: SendMessagePlugin = await SendMessage.createInstanceAsync();

  const receiver: MessageReceiver = await sendMessagePlugin.getMessageReceiverAsync(
    'PowerApps.AppMonitorReceiver',
    (versionInfo) => {
      let isCompatible = false;
      if (versionInfo === '1.0.0') {
        isCompatible = true;
      }
      return { isCompatible };
    }
  );
  if (receiver.isCompatible) {
    await receiver.sendMessage('initialize', (message: string) => {
      const parsedMessage = JSON.parse(message);
      if (parsedMessage.metrics) {
        for (const metric of parsedMessage.metrics) {
          // Log the metric
          loggerInstance.logMetric?.(metric);
        }
      }
    });
  }
}
