/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IPowerOperationExecutor } from '../powerDataRuntime.Types';

const ServiceName = 'PublishedAppTelemetry';
const enum TelemetryActionNames {
  trackEvent = 'trackEvent',
  trackException = 'trackException',
  trackMetric = 'trackMetric',
  startScenario = 'startScenario',
  endScenario = 'endScenario',
  setDefaultProperties = 'setDefaultProperties',
}

export class Log {
  private static _instance: Log | null = null;

  private constructor(private readonly _powerOperationExecutor: IPowerOperationExecutor) {}

  public static createInstance(powerOperationExecutor: IPowerOperationExecutor): Log {
    if (!Log._instance) {
      Log._instance = new Log(powerOperationExecutor);
    } else {
      Log.trackEvent('TelemetryLogger', {
        message: 'Attempted to create an instance when instance is already created.',
      });
    }
    return Log._instance;
  }

  // Since powerDataRuntime can be reset, we need to be able to reset the instance of Log as well.
  public static resetInstance(): void {
    Log._instance = null;
  }

  private static async _sendMessage(
    actionName: TelemetryActionNames,
    ...args: Array<string | number | boolean | object | undefined>
  ): Promise<void> {
    try {
      const instance = Log._getInstance();
      const result = await instance._powerOperationExecutor.execute(ServiceName, actionName, args);
      if (!result.success) {
        // Fallback to console logging if telemetry fails, since it is reasonable to assume the runtimeClient is failing.

        // eslint-disable-next-line no-console
        console.error({
          message: `PowerDataRuntime.TelemetryLogger: Failed to send telemetry message.`,
          error: result.error,
          telemetryArgs: args,
        });
      }
    } catch (error) {
      // Fallback to console logging if telemetry fails, since it is reasonable to assume the runtimeClient is failing.
      // we don't want to throw an error here, since we don't want to break the app if telemetry fails.

      // eslint-disable-next-line no-console
      console.error({
        message: `PowerDataRuntime.TelemetryLogger: Failed to send telemetry message.`,
        error,
        telemetryArgs: args,
      });
    }
  }

  public static trackEvent(eventName: string, eventData?: object) {
    return Log._sendMessage(TelemetryActionNames.trackEvent, `PowerDataRuntime.${eventName}`, eventData);
  }

  public static trackException(exception: object) {
    return Log._sendMessage(TelemetryActionNames.trackException, exception);
  }

  public static trackMetric(metricName: string, value: number) {
    return Log._sendMessage(TelemetryActionNames.trackMetric, `PowerDataRuntime.${metricName}`, value);
  }

  public static startScenario(scenarioName: string) {
    return Log._sendMessage(TelemetryActionNames.startScenario, `PowerDataRuntime.${scenarioName}`);
  }

  public static endScenario(scenarioName: string) {
    return Log._sendMessage(TelemetryActionNames.endScenario, `PowerDataRuntime.${scenarioName}`);
  }

  public static setDefaultProperties(properties: object) {
    return Log._sendMessage(TelemetryActionNames.setDefaultProperties, properties);
  }

  private static _getInstance(): Log {
    if (!Log._instance) {
      throw new Error('PowerDataRuntime.TelemetryLogger: Attempted to log telemetry prior to instantiation.');
    }
    return Log._instance;
  }
}
