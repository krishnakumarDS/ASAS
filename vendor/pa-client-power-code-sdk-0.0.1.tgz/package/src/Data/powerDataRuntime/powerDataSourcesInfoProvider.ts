/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IPowerDataSourcesInfoProvider } from './common/types';
import { DataSourcesInfo } from './powerDataRuntime.Types';
import { ErrorCodes, PowerDataRuntimeError } from './error';

/**
 * Singleton provider for managing data sources information.
 */
class PowerDataSourcesInfoProvider implements IPowerDataSourcesInfoProvider {
  private static instance: PowerDataSourcesInfoProvider | null = null;
  private dataSourcesInfo: DataSourcesInfo;

  /**
   * Private constructor to enforce the singleton pattern.
   * @param dataSourcesInfo The data sources information to initialize the provider with.
   */
  private constructor(dataSourcesInfo: DataSourcesInfo) {
    this.dataSourcesInfo = dataSourcesInfo;
  }

  /**
   * Retrieves the singleton instance of PowerDataSourcesInfoProvider.
   * If the instance does not exist, it initializes it with the provided data sources info.
   *
   * @param dataSourcesInfo Optional parameter to initialize the instance if it doesn't exist.
   * @returns The singleton instance of PowerDataSourcesInfoProvider.
   * @throws Error if the instance is not initialized and no dataSourcesInfo is provided.
   */
  public static getInstance(dataSourcesInfo?: DataSourcesInfo): PowerDataSourcesInfoProvider {
    if (!this.instance) {
      if (!dataSourcesInfo) {
        throw new PowerDataRuntimeError(ErrorCodes.DataSourcesInfoNotFound);
      }
      this.instance = new PowerDataSourcesInfoProvider(dataSourcesInfo);
    }
    return this.instance;
  }

  /**
   * Retrieves the data sources information.
   *
   * @returns A promise resolving to the data sources information.
   */
  public async getDataSourcesInfo(): Promise<DataSourcesInfo> {
    return this.dataSourcesInfo;
  }
}

export default PowerDataSourcesInfoProvider;
