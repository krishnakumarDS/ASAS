/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

/*
 * Converts an ArrayBuffer to a Base64 string
 * @param buffer - The ArrayBuffer to convert
 * @return The Base64 encoded string
 */
export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  return window.btoa(convertArrayBufferToString(buffer));
}

/*
 * Converts an ArrayBuffer to a string
 * @param buf - The ArrayBuffer to convert
 * @return The converted string
 */
export function convertArrayBufferToString(buf: ArrayBuffer): string {
  // String.fromCharCode range max is 65535
  if (buf.byteLength <= 65535) {
    return String.fromCharCode(...new Uint8Array(buf));
  }

  let binary = '';
  for (let i = 0, bytes = new Uint8Array(buf); i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return binary;
}

/**
 * Strict encode: encodeURIComponent, but also encode ( and )
 */
export function strictEncode(str: string): string {
  return encodeURIComponent(str).replace(/\(/g, '%28').replace(/\)/g, '%29');
}

/**
 * Extracts the Dataverse base URL and encoded path from a full Dataverse API URL.
 * @param url - The full Dataverse API URL (should contain /api/data/v9.0/)
 * @returns An object with baseUrl (up to /api/data/v9.0) and encodedPath (strict encoded path after /api/data/v9.0/)
 */
export function extractDataverseUrlParts(url: string): { baseUrl: string; encodedPath: string } {
  const baseUrlMatch = url.match(/^(https?:\/\/[^/]+\/api\/data\/v9\.0)/);
  const baseUrl = baseUrlMatch ? baseUrlMatch[1] : '';
  // Extract and encode the path after /api/data/v9.0/
  const pathMatch = url.match(/\/api\/data\/v9\.0\/(.+)$/);
  const encodedPath = pathMatch ? strictEncode(pathMatch[1]) : '';
  return { baseUrl, encodedPath };
}
