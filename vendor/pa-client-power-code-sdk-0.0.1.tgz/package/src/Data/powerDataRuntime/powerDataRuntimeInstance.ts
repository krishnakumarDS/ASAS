/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { PowerDataRuntime } from './powerDataRuntime';
import { IPowerDataSourcesInfoProvider, IXrmContext } from './common/types';
import { IPowerOperationExecutor } from './powerDataRuntime.Types';
import { Log } from './telemetry/log';

/**
 * Singleton instance of PowerDataRuntime
 */
let powerDataRuntimeInstance: PowerDataRuntime | undefined;

/**
 * Gets or creates a singleton instance of PowerDataRuntime
 * @param powerDataSourcesInfoProvider - Data sources info provider to initialize the PowerDataRuntime
 * @param powerOperationExecutor - Optional power operation executor to initialize the PowerDataRuntime
 * @param xrm - Optional xrm object to initialize the PowerDataRuntime
 * @returns PowerDataRuntime instance
 */
export function getPowerDataRuntime(
  powerDataSourcesInfoProvider: IPowerDataSourcesInfoProvider,
  powerOperationExecutor: IPowerOperationExecutor,
  xrm?: IXrmContext
): PowerDataRuntime {
  if (!powerDataRuntimeInstance) {
    powerDataRuntimeInstance = new PowerDataRuntime({
      powerDataSourcesInfoProvider,
      powerOperationExecutor,
      xrm: xrm ?? ({ WebApi: {} } as IXrmContext),
    });
  }
  return powerDataRuntimeInstance;
}

/**
 * Resets the PowerDataRuntime singleton instance.
 * Useful for testing or reinitialization.
 */
export function resetPowerDataRuntimeInstance(): void {
  powerDataRuntimeInstance = undefined;
  // Reset the Log instance as well to ensure a clean state
  Log.resetInstance();
}
