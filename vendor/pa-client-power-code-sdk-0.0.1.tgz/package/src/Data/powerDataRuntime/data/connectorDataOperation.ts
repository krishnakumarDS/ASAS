/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import {
  HttpMethod,
  IConnectionReference,
  IRuntimeClientProvider,
  IRuntimeMetadataClient,
} from '../common/types';
import { RuntimeDataSourceService } from '../metadata/runtimeDataSourceService';
import { IDataOperation, IDataSourceInfo, IOperationResult } from '../powerDataRuntime.Types';
import { createErrorResponse, DataOperationErrorMessages, ErrorCodes, PowerDataRuntimeError } from '../error';
import { ConnectorOperationName } from '../error/constants';

// =====================================
// Types and Interfaces
// =====================================

/**
 * Type for connection references mapping
 */
export type ConnectionReferences = Record<string, IConnectionReference>;

/**
 * Interface for connector operation configuration
 */
export interface IConnectorOperationConfig {
  tableName: string;
  apiId: string;
  runtimeUrl: string;
  connectionName: string;
  datasetName?: string;
  tableId: string;
  version?: string;
  datasetNameOverride?: string;
}

/**
 * Interface for connector operation parameters
 */
interface IUrlBuilder {
  runtimeUrl: string;
  connectionName: string;
  datasetName?: string;
  tableId: string;
  version?: string;
  isSharedSql: boolean;
}

// =====================================
// Main Class Implementation
// =====================================

/**
 * ConnectorDataOperation provides functionality for performing CRUD operations
 * against connector data sources using the Runtime Data Client.
 */
export class ConnectorDataOperation {
  // =====================================
  // Private Members
  // =====================================

  private readonly _clientProvider: IRuntimeClientProvider;
  private readonly _connectionsService: RuntimeDataSourceService;
  private _databaseReferences: ConnectionReferences | undefined;
  private _connectionReferences: ConnectionReferences | undefined;

  // =====================================
  // Constructor
  // =====================================

  constructor(clientProvider: IRuntimeClientProvider, connectionsService: RuntimeDataSourceService) {
    this._validateConstructorParams(clientProvider, connectionsService);
    this._clientProvider = clientProvider;
    this._connectionsService = connectionsService;
  }

  // =====================================
  // Public Methods
  // =====================================

  /**
   * Creates a new record in the specified table
   */
  public async createRecordAsync<TRequest, TResponse>(
    tableName: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>> {
    try {
      const { dataClient, connectionReference } = await this._getClientsAndConnection(tableName);
      const requestUrl = await this._buildTableUrl(tableName, connectionReference);
      const result = await dataClient.createDataAsync<TRequest, TResponse>(
        requestUrl,
        connectionReference.apiId as string,
        tableName,
        data,
        { operationName: ConnectorOperationName.CreateRecord }
      );
      return result;
    } catch (error) {
      return createErrorResponse<TResponse>(error, DataOperationErrorMessages.CreateFailed);
    }
  }

  /**
   * Updates an existing record in the specified table
   */
  public async updateRecordAsync<TRequest, TResponse>(
    tableName: string,
    id: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>> {
    try {
      const { dataClient, connectionReference } = await this._getClientsAndConnection(tableName);
      const requestUrl = await this._buildTableUrl(tableName, connectionReference, `/${id}`);
      const result = await dataClient.updateDataAsync<TRequest, TResponse>(
        requestUrl,
        connectionReference.apiId as string,
        tableName,
        data,
        { operationName: ConnectorOperationName.UpdateRecord }
      );
      return result as IOperationResult<TResponse>;
    } catch (error) {
      return createErrorResponse<TResponse>(error, DataOperationErrorMessages.UpdateFailed);
    }
  }

  /**
   * Deletes a record from the specified table
   */
  public async deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>> {
    try {
      const { dataClient, connectionReference } = await this._getClientsAndConnection(tableName);
      const requestUrl = await this._buildTableUrl(tableName, connectionReference, `/${id}`);
      const result = await dataClient.deleteDataAsync(
        requestUrl,
        connectionReference.apiId as string,
        tableName,
        { operationName: ConnectorOperationName.DeleteRecord }
      );

      return result;
    } catch (error) {
      return createErrorResponse(error, DataOperationErrorMessages.DeleteFailed);
    }
  }

  /**
   * Retrieves a single record from the specified table
   */
  public async retrieveRecordAsync<TResponse>(
    tableName: string,
    id: string,
    options: string
  ): Promise<IOperationResult<TResponse>> {
    try {
      const { dataClient, connectionReference } = await this._getClientsAndConnection(tableName);
      const requestUrl = await this._buildTableUrl(tableName, connectionReference, `/${id}${options}`);

      const result = await dataClient.retrieveDataAsync<TResponse>(
        requestUrl,
        connectionReference.apiId as string,
        tableName,
        HttpMethod.GET,
        undefined, // body
        { operationName: ConnectorOperationName.RetrieveRecord }
      );
      return result;
    } catch (error) {
      return createErrorResponse<TResponse>(error, DataOperationErrorMessages.RetrieveFailed);
    }
  }

  /**
   * Retrieves multiple records from the specified table
   */
  public async retrieveMultipleRecordsAsync<TResponse>(
    tableName: string,
    options: string
  ): Promise<IOperationResult<TResponse[]>> {
    try {
      const { dataClient, connectionReference } = await this._getClientsAndConnection(tableName);
      const requestUrl = await this._buildTableUrl(tableName, connectionReference, options, false);
      const result = await dataClient.retrieveDataAsync<TResponse[]>(
        requestUrl,
        connectionReference.apiId as string,
        tableName,
        HttpMethod.GET,
        undefined, // body
        { operationName: ConnectorOperationName.RetrieveMultipleRecords }
      );
      return result;
    } catch (error) {
      return createErrorResponse<TResponse[]>(error, DataOperationErrorMessages.RetrieveMultipleFailed);
    }
  }

  /**
   * Executes a custom operation on the data source
   */
  public async executeAsync<TRequest, TResponse>(
    operation: IDataOperation<TRequest>
  ): Promise<IOperationResult<TResponse>> {
    try {
      if (!operation?.connectorOperation) {
        throw new Error(
          `${DataOperationErrorMessages.InvalidRequest}: ${DataOperationErrorMessages.MissingConnectorOperation}`
        );
      }

      const tableName = operation.connectorOperation.tableName;
      const dataSourceInfo = await this._connectionsService.getDataSource(tableName);
      const { dataClient, connectionReference } = await this._getClientsAndConnection(tableName);
      const config = await this._getOperationConfig(operation, connectionReference, tableName);
      const requestUrl = await this._buildOperationUrl(operation, config);
      const bodyParam = await this._buildOperationBody(operation, tableName);
      const headers = await this._buildOperationHeader(operation, tableName);
      const httpMethod = this._getHttpMethod(
        requestUrl,
        dataSourceInfo,
        operation.connectorOperation.operationName
      );

      const responseInfo = dataSourceInfo.apis[operation.connectorOperation.operationName]?.responseInfo;
      const result = await dataClient.retrieveDataAsync<TResponse>(
        requestUrl,
        config.apiId,
        tableName,
        httpMethod,
        headers,
        bodyParam,
        {
          isExecuteAsync: true,
          // Use the connector operation name for telemetry, may be a better idea to use executeAsync
          // here and just log the connector operation name in the custom dimensions leaving comment for PR.
          operationName: `connectorDataOperation.${operation.connectorOperation.operationName}`,
          responseInfo,
        }
      );
      return result;
    } catch (error) {
      return createErrorResponse<TResponse>(error, DataOperationErrorMessages.ExecuteFailed);
    }
  }

  // =====================================
  // Private Methods
  // =====================================

  /**
   * Determines the appropriate HTTP method for a request
   * @param requestUrl - The URL for the request
   * @param dataSourceInfo - The data source information
   * @param operation - The operation name
   * @returns The HTTP method to use
   */
  private _getHttpMethod(requestUrl: string, dataSourceInfo: IDataSourceInfo, operation: string): HttpMethod {
    // Check if it's a SQL stored procedure (which requires POST)
    const isSqlStoredProcedure = requestUrl.indexOf('apim/sql') > -1;
    // Default to POST for SQL procedures, GET otherwise
    if (isSqlStoredProcedure) {
      return HttpMethod.POST;
    }

    const method = dataSourceInfo.apis[operation]?.method;
    if (method) {
      return method as HttpMethod;
    }

    return HttpMethod.GET;
  }

  /**
   * Builds the operation body parameters
   */
  private async _buildOperationBody<TRequest>(
    operation: IDataOperation<TRequest>,
    tableName: string
  ): Promise<string | undefined> {
    const operationName = operation?.connectorOperation?.operationName;
    if (operationName) {
      const dataSourceInfo = await this._connectionsService.getDataSource(tableName);

      const hasBodyParameter = dataSourceInfo?.apis?.[operationName]?.parameters?.some(
        (param) => param.in === 'body'
      );

      if (hasBodyParameter) {
        return await this._buildOperationBodyParam(operation, tableName);
      }
    }

    return undefined;
  }

  /**
   * Builds operation body parameters from the operation and data source info
   */
  private async _buildOperationBodyParam<TRequest>(
    operation: IDataOperation<TRequest>,
    tableName: string
  ): Promise<string> {
    const operationName = operation.connectorOperation?.operationName;
    if (!operationName) {
      return '{}';
    }

    const dataSourceInfo = await this._connectionsService.getDataSource(tableName);
    const apiParams = dataSourceInfo?.apis?.[operationName]?.parameters || [];
    const rawParams = operation.connectorOperation?.parameters || [];
    let bodyValue: Record<string, unknown> = {};

    apiParams.forEach((param, index) => {
      if (typeof rawParams === 'object' && rawParams !== null) {
        if (apiParams[index].in === 'body') {
          const value = (rawParams as Record<string, unknown>)[param.name];
          if (param.name === 'body') {
            bodyValue = value as Record<string, unknown>;
            return;
          }
          if (value !== undefined && value !== null) {
            bodyValue[param.name] = value;
          }
        }
      }
    });

    return JSON.stringify(bodyValue);
  }

  /**
   * Builds the operation header for a given data operation if required.
   *
   * @template TRequest - The type of the request payload for the data operation.
   * @param dataOperationRequest - The data operation containing details about the connector operation.
   * @param tableName - The name of the table associated with the data operation.
   * @returns A promise that resolves to the operation header as a string if a header parameter is required,
   *          or `undefined` if no header parameter is needed.
   */
  private async _buildOperationHeader<TRequest>(
    dataOperationRequest: IDataOperation<TRequest>,
    tableName: string
  ): Promise<{ [key: string]: string } | undefined> {
    const operationName = dataOperationRequest.connectorOperation?.operationName;
    if (operationName) {
      const dataSourceInfo = await this._connectionsService.getDataSource(tableName);
      const hasHeaderParameter = dataSourceInfo?.apis?.[operationName]?.parameters?.some(
        (param) => param.in === 'header'
      );

      if (hasHeaderParameter) {
        return await this._buildOperationHeaderParam(dataOperationRequest, tableName);
      }
    }
    return undefined;
  }

  /**
   * Builds the operation header parameters as a JSON string for a given data operation.
   *
   * @template TRequest - The type of the request object for the data operation.
   * @param dataOperationRequest - The data operation containing connector operation details and parameters.
   * @param tableName - The name of the table associated with the data operation.
   * @returns A promise that resolves to a JSON string representing the header parameters,
   *          or `undefined` if no `header` parameters are available.
   */
  private async _buildOperationHeaderParam<TRequest>(
    dataOperationRequest: IDataOperation<TRequest>,
    tableName: string
  ): Promise<{ [key: string]: string } | undefined> {
    const operationName = dataOperationRequest.connectorOperation?.operationName;
    if (!operationName) {
      return {};
    }

    const dataSourceInfo = await this._connectionsService.getDataSource(tableName);
    const apiParamSpec = dataSourceInfo?.apis?.[operationName]?.parameters || [];
    const inputParams = dataOperationRequest.connectorOperation?.parameters;
    const headers: { [key: string]: string } = {};

    // This method does not check for required header parameters
    // If the header parameter is required & is not provided, the connector will throw an error
    // when the operation is executed.
    if (!inputParams) {
      return undefined;
    }

    if (typeof inputParams === 'string') {
      // Handle string parameter - often used for single parameter operations
      if (apiParamSpec.length === 1 && apiParamSpec[0].in === 'header') {
        headers[apiParamSpec[0].name] = inputParams;
      }
    }

    if (typeof inputParams === 'object' && !Array.isArray(inputParams)) {
      // Handle object parameters - match by parameter name
      apiParamSpec.forEach((param) => {
        if (param.in === 'header' && param.name in inputParams) {
          headers[param.name] = (inputParams as Record<string, string>)[param.name];
        }
      });
    }

    if (Array.isArray(inputParams)) {
      // Handle array parameters - match by index
      apiParamSpec.forEach((param, index) => {
        if (param.in === 'header' && inputParams[index] !== undefined) {
          headers[param.name] = inputParams[index];
        }
      });
    }

    return headers;
  }

  /**
   * Constructs the request URL for table operations
   * @param tableName - The name of the table
   * @param connectionReference - The connection reference
   * @param options - Optional URL parameters
   * @param encodeOptions - Whether to encode the options
   * @returns The constructed URL
   */
  private async _buildTableUrl(
    tableName: string,
    connectionReference: IConnectionReference,
    options: string = '',
    encodeOptions: boolean = true
  ): Promise<string> {
    const dataSourceInfo = await this._connectionsService.getDataSource(tableName);

    const isSharedSql = (connectionReference.apiId ?? '').indexOf('shared_sql') > -1;
    const isSharePoint = (connectionReference.apiId ?? '').indexOf('shared_sharepointonline') > -1;
    const urlBuilder: IUrlBuilder = {
      runtimeUrl: connectionReference.runtimeUrl ?? '',
      connectionName: connectionReference.connectionName ?? '',
      datasetName: connectionReference.datasetName
        ? isSharedSql
          ? connectionReference.datasetNameOverride
          : isSharePoint
          ? encodeURIComponent(encodeURIComponent(connectionReference.datasetName))
          : encodeURIComponent(connectionReference.datasetName)
        : '',
      tableId: isSharedSql
        ? encodeURIComponent(encodeURIComponent(dataSourceInfo.tableId))
        : dataSourceInfo.tableId,
      version: dataSourceInfo.version,
      isSharedSql,
    };

    return this._constructUrl(urlBuilder, options, encodeOptions);
  }

  /**
   * Builds the operation URL
   */
  private async _buildOperationUrl<TRequest>(
    operation: IDataOperation<TRequest>,
    config: IConnectorOperationConfig
  ): Promise<string> {
    const operationName = operation.connectorOperation?.operationName;
    if (!operationName) {
      throw new Error(
        `${DataOperationErrorMessages.InvalidOperationParameters}: ${DataOperationErrorMessages.MissingOperationName}`
      );
    }

    const dataSourceInfo = await this._connectionsService.getDataSource(config.tableName);
    const isSharedSql = (config.apiId ?? '').indexOf('shared_sql') > -1;
    const path = dataSourceInfo.apis[operationName].path;

    if (isSharedSql) {
      return this._buildSharedSqlOperationUrl(config, path);
    }

    return this._buildStandardOperationUrl(operation, config, operationName, path);
  }

  /**
   * Gets the connection references
   */
  private async _getConnectionReferencesAsync(): Promise<ConnectionReferences> {
    if (this._connectionReferences) {
      return this._connectionReferences;
    }

    const metadataClient = await this._getMetadataClient();
    const response = await metadataClient.getAppConnectionConfigsAsync();
    this._connectionReferences = response.data as unknown as ConnectionReferences;
    return this._connectionReferences!;
  }

  /**
   * Gets the database references
   */
  private async _getDatabaseReferencesAsync(): Promise<ConnectionReferences> {
    if (this._databaseReferences) {
      return this._databaseReferences;
    }

    const metadataClient = await this._getMetadataClient();
    const response = await metadataClient.getAppDataSourceConfigsAsync();
    this._databaseReferences = response.data as unknown as ConnectionReferences;
    return this._databaseReferences!;
  }

  /**
   * Gets the metadata client instance
   */
  private async _getMetadataClient(): Promise<IRuntimeMetadataClient> {
    const metadataClient = await this._clientProvider.getMetadataClientAsync();
    if (!metadataClient) {
      throw new PowerDataRuntimeError(ErrorCodes.MetadataClientNotAvailable);
    }
    return metadataClient;
  }

  /**
   * Gets the connection reference for a table
   */
  private _getConnectionReference(tableName: string): IConnectionReference {
    const connectionReference = this._connectionReferences?.[tableName];
    if (!connectionReference) {
      throw new PowerDataRuntimeError(ErrorCodes.ConnectionReferenceNotFound, tableName);
    }
    return connectionReference;
  }

  /**
   * Gets both the data client and connection reference
   */
  private async _getClientsAndConnection(tableName: string) {
    await this._getReferences();
    const dataClient = await this._clientProvider.getDataClientAsync();
    if (!dataClient) {
      throw new PowerDataRuntimeError(ErrorCodes.DataClientNotAvailable);
    }
    const connectionReference = this._getConnectionReference(tableName);
    return { dataClient, connectionReference };
  }

  /**
   * Builds the URL for shared SQL operations
   */
  private _buildSharedSqlOperationUrl(config: IConnectorOperationConfig, path: string): string {
    const version = config.version ? `/${config.version}/` : '/';
    return `${config.runtimeUrl}/${config.connectionName}${version}datasets/${config.datasetName}/procedures${path}`;
  }

  /**
   * Builds the URL for standard operations
   */
  private async _buildStandardOperationUrl<TRequest>(
    operation: IDataOperation<TRequest>,
    config: IConnectorOperationConfig,
    operationName: string,
    path: string
  ): Promise<string> {
    const dataSourceInfo = await this._connectionsService.getDataSource(config.tableName);
    const apiParams = dataSourceInfo.apis[operationName]?.parameters || [];

    // Handle parameters that could be an object, array, or string
    const operationParams = operation.connectorOperation?.parameters;
    let rawParams: unknown[] = [config.connectionName];

    // Handle different parameter types
    if (operationParams !== undefined) {
      if (typeof operationParams === 'string') {
        // Handle string parameter - often used for single parameter operations
        if (apiParams.length > 0) {
          rawParams.push(operationParams);
        }
      } else if (typeof operationParams === 'object' && !Array.isArray(operationParams)) {
        // Handle object parameters - match by parameter name (normalized)
        apiParams.forEach((param) => {
          if (operationParams) {
            const value = this._getNormalizedParamValue(
              operationParams as Record<string, unknown>,
              param.name
            );
            if (value !== undefined) {
              rawParams.push(value);
            }
          }
        });
      } else if (Array.isArray(operationParams)) {
        // Handle array parameters - match by index
        rawParams = [config.connectionName, ...operationParams];
      }
    }

    const { processedPath, queryParams } = this._processParameters(apiParams, rawParams, path);
    const separator = queryParams ? (processedPath.includes('?') ? '&' : '?') : '';
    return `${config.runtimeUrl}${processedPath}${separator}${queryParams}`;
  }

  /**
   * Normalizes the parameter name by replacing hyphens with underscores and performs case-insensitive matching
   */
  private _getNormalizedParamValue(obj: Record<string, unknown>, paramName: string): unknown {
    const normalizedParamName = paramName.replace(/-/g, '_').toLowerCase();
    const foundKey = Object.keys(obj).find(
      (key) => key.replace(/-/g, '_').toLowerCase() === normalizedParamName
    );
    return foundKey !== undefined ? obj[foundKey] : undefined;
  }

  /**
   * Processes operation parameters into path and query parameters
   */
  private _processParameters(
    apiParams: Array<{ name: string; in: string; required: boolean }>,
    rawParams: unknown[],
    path: string
  ): { processedPath: string; queryParams: string } {
    const usedParams = new Set<string>();
    let processedPath = path;
    const queryParams: string[] = [];

    apiParams.forEach((param, index) => {
      const paramValue = rawParams[index];

      if (paramValue === undefined) {
        return;
      }

      if (param.in === 'path') {
        const placeholder = `{${param.name}}`;
        if (processedPath.includes(placeholder)) {
          processedPath = processedPath.replace(placeholder, encodeURIComponent(String(paramValue)));
          usedParams.add(param.name);
        }
      } else if (param.in === 'query') {
        queryParams.push(`${encodeURIComponent(param.name)}=${encodeURIComponent(String(paramValue))}`);
        usedParams.add(param.name);
      }
    });

    return {
      processedPath,
      queryParams: queryParams.join('&'),
    };
  }

  /**
   * Gets the operation configuration
   */
  private async _getOperationConfig<TRequest>(
    operation: IDataOperation<TRequest>,
    connectionReference: IConnectionReference,
    tableName: string
  ): Promise<IConnectorOperationConfig> {
    if (!operation.connectorOperation) {
      throw new Error(
        `${DataOperationErrorMessages.InvalidRequest}: ${DataOperationErrorMessages.MissingConnectorOperation}`
      );
    }

    const dataSourceInfo = await this._connectionsService.getDataSource(tableName);

    const config = {
      tableName,
      apiId: connectionReference.apiId ?? '',
      runtimeUrl: connectionReference.runtimeUrl ?? '',
      connectionName: connectionReference.connectionName ?? '',
      datasetName: connectionReference.datasetName ?? '',
      tableId: dataSourceInfo.tableId,
      version: dataSourceInfo.version,
    };

    return config;
  }

  /**
   * Initializes the clients
   */
  private async _getReferences(): Promise<void> {
    await this._getConnectionReferencesAsync();
    await this._getDatabaseReferencesAsync();
  }

  /**
   * Validates constructor parameters
   */
  private _validateConstructorParams(
    clientProvider: IRuntimeClientProvider,
    connectionsService: RuntimeDataSourceService
  ): void {
    if (!clientProvider) {
      throw new PowerDataRuntimeError(ErrorCodes.ClientProviderNotAvailable);
    }
    if (!connectionsService) {
      throw new PowerDataRuntimeError(ErrorCodes.DataSourceServiceNotAvailable);
    }
  }

  /**
   * Constructs the final URL
   */
  private _constructUrl(
    urlBuilder: IUrlBuilder,
    options: string = '',
    encodeOptions: boolean = true
  ): string {
    const apiVersion = urlBuilder.version ? `/${urlBuilder.version}/` : '/';
    const encodedOptions =
      encodeOptions && options ? options.charAt(0) + encodeURIComponent(options.slice(1)) : options;

    if (urlBuilder.datasetName) {
      return `${urlBuilder.runtimeUrl}/${urlBuilder.connectionName}${apiVersion}datasets/${urlBuilder.datasetName}/tables/${urlBuilder.tableId}/items${encodedOptions}`;
    }

    return `${urlBuilder.runtimeUrl}/${urlBuilder.connectionName}/tables/${urlBuilder.tableId}/items${encodedOptions}`;
  }
}
