/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import {
  IDataOperation,
  IDataOperations,
  IOperationOptions,
  IOperationResult,
} from '../powerDataRuntime.Types';
import { DataSources } from '../common/types';
import { DataverseDataOperation } from './dataverseDataOperation';
import { ConnectorDataOperation } from './connectorDataOperation';
import { createErrorResponse, DataOperationErrorMessages } from '../error';
import { RuntimeDataSourceService } from '../metadata/runtimeDataSourceService';

/**
 * RuntimeDataOperations provides a unified interface for performing data operations
 * across different data sources.
 */
export class RuntimeDataOperations implements IDataOperations {
  // Static identifiers for services and actions
  // Used to identify specific services and actions within the PowerApps environment
  constructor(
    private readonly _dataverseOperation: DataverseDataOperation,
    private readonly _connectorOperation: ConnectorDataOperation,
    private readonly _connectionsService: RuntimeDataSourceService
  ) {}

  /**
   * Creates a new record in the specified data source.
   * @param tableName - The name of the table.
   * @param data - The record data to create.
   * @returns A promise that resolves to the operation result.
   * @throws DataOperationError if the operation fails.
   */
  public async createRecordAsync<TRequest, TResponse>(
    tableName: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>> {
    try {
      this._validateParams({ tableName, data });
      const executor = await this._getExecutor(tableName);
      return await executor.createRecordAsync<TRequest, TResponse>(tableName, data);
    } catch (error) {
      return createErrorResponse<TResponse>(error, 'Create record operation failed');
    }
  }

  /**
   * Updates an existing record in the specified data source.
   * @param tableName - The name of the table.
   * @param id - The ID of the record to update.
   * @param data - The updated record data.
   * @returns A promise that resolves to the operation result.
   * @throws DataOperationError if the operation fails.
   */
  public async updateRecordAsync<TRequest, TResponse>(
    tableName: string,
    id: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>> {
    try {
      this._validateParams({ tableName, id, data });
      const executor = await this._getExecutor(tableName);
      return await executor.updateRecordAsync<TRequest, TResponse>(tableName, id, data);
    } catch (error) {
      return createErrorResponse<TResponse>(error, 'Update record operation failed');
    }
  }

  /**
   * Deletes a record from the specified data source.
   * @param tableName - The name of the table.
   * @param id - The ID of the record to delete.
   * @returns A promise that resolves to the operation result.
   * @throws DataOperationError if the operation fails.
   */
  public async deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>> {
    try {
      this._validateParams({ tableName, id });
      const executor = await this._getExecutor(tableName);
      return await executor.deleteRecordAsync(tableName, id);
    } catch (error) {
      return createErrorResponse(error, 'Delete record operation failed');
    }
  }

  /**
   * Retrieves a record from the specified data source.
   * @param tableName - The name of the table.
   * @param id - The ID of the record to retrieve.
   * @param options - Optional operation options.
   * @returns A promise that resolves to the operation result.
   * @throws DataOperationError if the operation fails.
   */
  public async retrieveRecordAsync<TResponse>(
    tableName: string,
    id: string,
    options?: IOperationOptions
  ): Promise<IOperationResult<TResponse>> {
    try {
      this._validateParams({ tableName, id });
      const executor = await this._getExecutor(tableName);
      const optionsString = this._convertOptionsToString(options);
      return await executor.retrieveRecordAsync<TResponse>(
        tableName,
        id,
        optionsString,
        options?.maxPageSize
      );
    } catch (error) {
      return createErrorResponse<TResponse>(error, 'Retrieve record operation failed');
    }
  }

  /**
   * Retrieves multiple records from the specified data source.
   * @param tableName - The name of the table.
   * @param options - Optional operation options.
   * @returns A promise that resolves to the operation result.
   * @throws DataOperationError if the operation fails.
   */
  public async retrieveMultipleRecordsAsync<TResponse>(
    tableName: string,
    options?: IOperationOptions
  ): Promise<IOperationResult<TResponse[]>> {
    try {
      this._validateParams({ tableName });
      const executor = await this._getExecutor(tableName);
      const optionsString = this._convertOptionsToString(options);
      return await executor.retrieveMultipleRecordsAsync<TResponse>(
        tableName,
        optionsString,
        options?.maxPageSize
      );
    } catch (error) {
      return createErrorResponse<TResponse[]>(error, 'Retrieve multiple records operation failed');
    }
  }

  /**
   * Executes a data operation on the specified data source.
   * @param operation - The operation to execute
   * @returns A promise that resolves to the operation result.
   * @throws DataOperationError if the operation fails.
   */
  public async executeAsync<TRequest, TResponse>(
    operation: IDataOperation<TRequest>
  ): Promise<IOperationResult<TResponse>> {
    try {
      this._validateParams({ operation });
      const executor = await this._getExecutor(
        '',
        operation.connectorOperation ? DataSources.Connector : DataSources.Dataverse
      );
      return await executor.executeAsync<TRequest, TResponse>(operation);
    } catch (error) {
      return createErrorResponse<TResponse>(error, 'Execute operation failed');
    }
  }

  /**
   * Retrieves the appropriate executor based on the data source.
   * @param dataSource - The data source to retrieve the executor for.
   * @returns The corresponding executor instance.
   * @throws DataOperationError if the data source is invalid.
   * // TODO: Add Dataverse support
   */
  private async _getExecutor(
    tableName: string,
    dataSource?: DataSources.Dataverse | DataSources.Connector
  ): Promise<ConnectorDataOperation | DataverseDataOperation> {
    const dataSourceType =
      dataSource || (await this._connectionsService.getDataSource(tableName)).dataSourceType;
    switch (dataSourceType) {
      case DataSources.Dataverse:
        return this._dataverseOperation;
      case DataSources.Connector:
        return this._connectorOperation;
      default:
        return this._connectorOperation;
    }
  }

  /**
   * Validates the input parameters for data operations.
   * @param params - The parameters to validate.
   * @throws DataOperationError if validation fails.
   */
  private _validateParams(params: Record<string, unknown>): void {
    for (const [key, value] of Object.entries(params)) {
      if (!value) {
        throw new Error(`${DataOperationErrorMessages.InvalidOperationParameters}: ${key} is required`);
      }
    }
  }

  /**
   * Converts operation options to a query string format.
   * @param options - The operation options to convert.
   * @returns The formatted query string.
   */
  private _convertOptionsToString(options?: IOperationOptions): string {
    if (!options) {
      return '';
    }

    this._validateOptions(options);

    const parts: string[] = [];
    if (options.select && options.select.length > 0) {
      parts.push(
        `$select=${encodeURIComponent(
          options.select.map((s) => s.trim().replace(/%20/g, '+').replace(/'/g, '%27')).join(',')
        )}`
      );
    }

    if (options.filter) {
      const encodedFilter = encodeURIComponent(options.filter.trim())
        .replace(/%20/g, '+')
        .replace(/'/g, '%27');
      parts.push(`$filter=${encodedFilter}`);
    }

    if (options.orderBy && options.orderBy.length > 0) {
      parts.push(
        `$orderby=${encodeURIComponent(
          options.orderBy.map((s) => s.trim().replace(/%20/g, '+').replace(/'/g, '%27')).join(',')
        )}`
      );
    }

    if (options.top !== undefined && options.top !== null) {
      parts.push(`$top=${options.top}`);
    }

    if (options.skip !== undefined && options.skip !== null) {
      parts.push(`$skip=${options.skip}`);
    }

    if (options.count !== undefined && options.count !== null) {
      parts.push(`$count=${options.count}`);
    }

    if (options.skipToken && options.skipToken.trim() !== '') {
      parts.push(`$skiptoken=${encodeURIComponent(options.skipToken.trim())}`);
    }

    return parts.length ? `?${parts.join('&')}` : '';
  }

  /**
   * Validates the operation options.
   * @param options - The operation options to validate.
   * @throws Error if validation fails.
   */
  private _validateOptions(options: IOperationOptions): void {
    // maxPageSize must be a number
    if (options.maxPageSize && typeof options.maxPageSize !== 'number') {
      throw new Error(
        `${DataOperationErrorMessages.InvalidOperationParameters}: maxPageSize must be a number`
      );
    }

    /* 
    select
    - must be an array of string
    - no empty strings allowed
    - no null or undefined values allowed
    */
    if (options.select) {
      if (!Array.isArray(options.select)) {
        throw new Error(
          `${DataOperationErrorMessages.InvalidOperationParameters}: select must be an array of strings`
        );
      }
      if (options.select.some((s) => typeof s !== 'string' || s.trim() === '')) {
        throw new Error(
          `${DataOperationErrorMessages.InvalidOperationParameters}: select must contain only non-empty strings`
        );
      }
    }

    // filter must be a string
    if (options.filter && typeof options.filter !== 'string') {
      throw new Error(`${DataOperationErrorMessages.InvalidOperationParameters}: filter must be a string`);
    }

    // orderBy must be an array of strings
    if (options.orderBy) {
      if (!Array.isArray(options.orderBy)) {
        throw new Error(
          `${DataOperationErrorMessages.InvalidOperationParameters}: orderBy must be an array of strings`
        );
      }
      if (options.orderBy.some((s) => typeof s !== 'string' || s.trim() === '')) {
        throw new Error(
          `${DataOperationErrorMessages.InvalidOperationParameters}: orderBy must contain only non-empty strings`
        );
      }
    }

    // top must be a number
    if (options.top && typeof options.top !== 'number') {
      throw new Error(`${DataOperationErrorMessages.InvalidOperationParameters}: top must be a number`);
    }

    // skip must be a number
    if (options.skip && typeof options.skip !== 'number') {
      throw new Error(`${DataOperationErrorMessages.InvalidOperationParameters}: skip must be a number`);
    }

    // count must be a boolean
    if (options.count && typeof options.count !== 'boolean') {
      throw new Error(`${DataOperationErrorMessages.InvalidOperationParameters}: count must be a boolean`);
    }
  }
}
