/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import {
  DataSources,
  HttpMethod,
  IRuntimeClientProvider,
  IRuntimeDataClient,
  IRuntimeMetadataClient,
  IXrmContext,
} from '../common/types';
import { Log } from '../telemetry/log';
import { IDataOperation, IDataSourceInfo, IOperationResult } from '../powerDataRuntime.Types';
import { createErrorResponse, DataOperationErrorMessages, ErrorCodes, PowerDataRuntimeError } from '../error';
import { DataverseOperationName } from '../error/constants';
import { RuntimeDataSourceService } from '../metadata/runtimeDataSourceService';

// OData annotation constants
export const ODATA_CONTEXT = '@odata.context';
export const ODATA_NEXT_LINK = '@odata.nextLink';
export const CRM_TOTAL_RECORD_COUNT = '@Microsoft.Dynamics.CRM.totalrecordcount';
export const CRM_TOTAL_RECORD_COUNT_LIMIT_EXCEEDED = '@Microsoft.Dynamics.CRM.totalrecordcountlimitexceeded';
export const CRM_GLOBAL_METADATA_VERSION = '@Microsoft.Dynamics.CRM.globalmetadataversion';

/**
 * DataverseDataOperation provides functionality for performing CRUD operations
 * against the Dataverse data source using the XRM WebApi or runtime metadata client.
 */
export class DataverseDataOperation {
  // Static identifiers for services and actions
  // Used to identify specific services and actions within the PowerApps environment
  private readonly _xrm: IXrmContext;
  private readonly _dataverseDataSourceService: RuntimeDataSourceService;
  private readonly _clientProvider: IRuntimeClientProvider;

  private _databaseReferences: DatabaseReferences | undefined;

  constructor(
    xrm: IXrmContext,
    dataverseDataSourceService: RuntimeDataSourceService,
    clientProvider: IRuntimeClientProvider
  ) {
    this._xrm = xrm;
    this._dataverseDataSourceService = dataverseDataSourceService;
    this._clientProvider = clientProvider;
  }

  /**
   * Creates a new record in Dataverse
   * @param tableName - The name of the table
   * @param data - The record data to create
   * @returns Promise resolving to operation result
   */
  public async createRecordAsync<TRequest, TResponse>(
    tableName: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>> {
    if (this._hasCrm()) {
      // XRM WebApi code path
      try {
        this._validateParams({ tableName, data });
        const response = await this._xrm.WebApi.createRecord<TRequest, TResponse>(tableName, data);
        return this._createSuccessResult<TResponse>(response);
      } catch (error) {
        Log.trackEvent('DataverseDataOperation.CreateRecordFailed', {
          message: '[DataverseDataOperation] Failed to create record',
          tableName,
          error,
        });
        return createErrorResponse<TResponse>(error, DataOperationErrorMessages.CreateFailed);
      }
    } else {
      return this._executeNativeDataverseOperation<TRequest, TResponse>(
        tableName,
        (dataSourceInfo, tblName) => this._getDataverseRequestUrl(dataSourceInfo, tblName),
        async (dataClient, requestUrl, dataSourceInfo) => {
          const dataverseResponse = await dataClient.createDataAsync<TRequest, TResponse>(
            requestUrl,
            DataSources.Dataverse, // Use environment name for Dataverse authentication
            tableName,
            data,
            {
              operationName: DataverseOperationName.CreateRecord,
              datasetName: dataSourceInfo.datasetName,
              isDataVerseOperation: true,
            }
          );
          const returnValue: IOperationResult<TResponse> = {
            success: dataverseResponse.success,
            data: dataverseResponse.data,
            error: dataverseResponse.error,
          };
          return returnValue;
        },
        DataOperationErrorMessages.CreateFailed
      );
    }
  }

  /**
   * Updates an existing record in Dataverse
   * @param tableName - The name of the table
   * @param id - The record identifier
   * @param data - The updated record data
   * @returns Promise resolving to operation result
   */
  public async updateRecordAsync<TRequest, TResponse>(
    tableName: string,
    id: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>> {
    if (this._hasCrm()) {
      try {
        this._validateParams({ tableName, id, data });
        const response = await this._xrm.WebApi.updateRecord<TRequest, TResponse>(tableName, id, data);
        return this._createSuccessResult<TResponse>(response);
      } catch (error) {
        Log.trackEvent('DataverseDataOperation.UpdateRecordFailed', {
          message: '[DataverseDataOperation] Failed to update record',
          tableName,
          id,
          error,
        });
        return createErrorResponse<TResponse>(error, DataOperationErrorMessages.UpdateFailed);
      }
    } else {
      return this._executeNativeDataverseOperation<TRequest, TResponse>(
        tableName,
        (dataSourceInfo, tblName) => this._getDataverseRequestUrl(dataSourceInfo, tblName, `(${id})`),
        async (dataClient, requestUrl, dataSourceInfo) => {
          const dataverseResponse = await dataClient.updateDataAsync<TRequest, TResponse>(
            requestUrl,
            DataSources.Dataverse,
            tableName,
            data,
            {
              operationName: DataverseOperationName.UpdateRecord,
              datasetName: dataSourceInfo.datasetName,
              isDataVerseOperation: true,
            }
          );
          const returnValue: IOperationResult<TResponse> = {
            success: dataverseResponse.success,
            data: dataverseResponse.data,
            error: dataverseResponse.error,
          };
          return returnValue;
        },
        DataOperationErrorMessages.UpdateFailed
      );
    }
  }

  /**
   * Deletes a record from Dataverse
   * @param tableName - The name of the table
   * @param id - The record identifier
   * @returns Promise resolving to operation result
   */
  public async deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>> {
    if (this._hasCrm()) {
      try {
        this._validateParams({ tableName, id });
        await this._xrm.WebApi.deleteRecord(tableName, id);
        return this._createSuccessResult<void>(undefined);
      } catch (error) {
        Log.trackEvent('DataverseDataOperation.DeleteRecordFailed', {
          message: '[DataverseDataOperation] Failed to delete record',
          tableName,
          id,
          error,
        });
        return createErrorResponse(error, DataOperationErrorMessages.DeleteFailed);
      }
    } else {
      return this._executeNativeDataverseOperation<void, void>(
        tableName,
        (dataSourceInfo, tblName) => this._getDataverseRequestUrl(dataSourceInfo, tblName, `(${id})`),
        async (dataClient, requestUrl, dataSourceInfo) => {
          const dataverseResponse = await dataClient.deleteDataAsync(
            requestUrl,
            DataSources.Dataverse,
            tableName,
            {
              operationName: DataverseOperationName.DeleteRecord,
              datasetName: dataSourceInfo.datasetName,
              isDataVerseOperation: true,
            }
          );
          const returnValue: IOperationResult<void> = {
            success: dataverseResponse.success,
            data: dataverseResponse.data,
            error: dataverseResponse.error,
          };
          return returnValue;
        },
        DataOperationErrorMessages.DeleteFailed
      );
    }
  }

  /**
   * Retrieves a single record from Dataverse
   * @param tableName - The name of the table
   * @param id - The record identifier
   * @param options - The retrieval options
   * @returns Promise resolving to operation result
   */
  public async retrieveRecordAsync<TResponse>(
    tableName: string,
    id: string,
    options: string,
    maxPageSize: number = 500 // Default max page size
  ): Promise<IOperationResult<TResponse>> {
    if (this._hasCrm()) {
      try {
        this._validateParams({ tableName, id });
        const response = await this._xrm.WebApi.retrieveRecord<TResponse>(tableName, id, options);
        return this._createSuccessResult<TResponse>(response);
      } catch (error) {
        Log.trackEvent('DataverseDataOperation.RetrieveRecordFailed', {
          message: '[DataverseDataOperation] Failed to retrieve record',
          tableName,
          id,
          options,
          error,
        });
        return createErrorResponse<TResponse>(error, DataOperationErrorMessages.RetrieveFailed);
      }
    } else {
      // Build Prefer header with updated maxPageSize
      const headers = { Prefer: `odata.maxpagesize=${maxPageSize},odata.include-annotations=*` };
      return this._executeNativeDataverseOperation<undefined, TResponse>(
        tableName,
        (dataSourceInfo, tblName) =>
          this._getDataverseRequestUrl(dataSourceInfo, tblName, `/${id}${options}`),
        async (dataClient, requestUrl, dataSourceInfo) => {
          const dataverseResponse = await dataClient.retrieveDataAsync<TResponse>(
            requestUrl,
            DataSources.Dataverse,
            tableName,
            HttpMethod.GET,
            headers,
            undefined, // No body for GET requests
            {
              operationName: DataverseOperationName.RetrieveRecord,
              datasetName: dataSourceInfo.datasetName,
              isDataVerseOperation: true,
            }
          );
          const returnValue: IOperationResult<TResponse> = {
            success: dataverseResponse.success,
            data: dataverseResponse.data,
            error: dataverseResponse.error,
          };
          return returnValue;
        },
        DataOperationErrorMessages.RetrieveFailed
      );
    }
  }

  /**
   * Retrieves multiple records from Dataverse
   * @param tableName - The name of the table
   * @param options - The retrieval options
   * @param maxPageSize - Optional maximum page size
   * @returns Promise resolving to operation result
   */
  public async retrieveMultipleRecordsAsync<TResponse>(
    tableName: string,
    options: string,
    maxPageSize: number = 500 // Default max page size,
  ): Promise<IOperationResult<TResponse[]>> {
    if (this._hasCrm()) {
      try {
        this._validateParams({ tableName });
        const response = await this._xrm.WebApi.retrieveMultipleRecords<TResponse[]>(
          tableName,
          options,
          maxPageSize
        );
        return this._createSuccessResult<TResponse[]>(response);
      } catch (error) {
        Log.trackEvent('DataverseDataOperation.RetrieveMultipleRecordsFailed', {
          message: '[DataverseDataOperation] Failed to retrieve multiple records',
          tableName,
          options,
          maxPageSize,
          error,
        });
        return createErrorResponse<TResponse[]>(error, DataOperationErrorMessages.RetrieveMultipleFailed);
      }
    } else {
      // Build Prefer header with updated maxPageSize
      const headers = { Prefer: `odata.maxpagesize=${maxPageSize},odata.include-annotations=*` };
      return this._executeNativeDataverseOperation<undefined, TResponse[]>(
        tableName,
        (dataSourceInfo, tblName) => this._getDataverseRequestUrl(dataSourceInfo, tblName, options),
        async (dataClient, requestUrl, dataSourceInfo) => {
          const dataverseResponse = await dataClient.retrieveDataAsync<{
            value: TResponse[];
            [ODATA_CONTEXT]?: string;
            [CRM_TOTAL_RECORD_COUNT]?: number;
            [CRM_TOTAL_RECORD_COUNT_LIMIT_EXCEEDED]?: boolean;
            [CRM_GLOBAL_METADATA_VERSION]?: string;
            [ODATA_NEXT_LINK]?: string;
          }>(
            requestUrl,
            DataSources.Dataverse,
            tableName,
            HttpMethod.GET,
            headers,
            undefined, // No body for GET requests
            {
              operationName: DataverseOperationName.RetrieveMultipleRecords,
              datasetName: dataSourceInfo.datasetName,
              isDataVerseOperation: true,
            }
          );
          const returnValue: IOperationResult<TResponse[]> = {
            success: dataverseResponse.success,
            data: dataverseResponse?.data?.value || [],
            skipToken: extractSkipToken(dataverseResponse?.data?.[ODATA_NEXT_LINK]),
            error: dataverseResponse.error,
          };
          return returnValue;
        },
        DataOperationErrorMessages.RetrieveMultipleFailed
      );
    }
  }

  /**
   * Executes a custom Dataverse operation
   * @param operation - The operation to execute
   * @returns Promise resolving to operation result
   */
  public async executeAsync<TRequest, TResponse>(
    operation: IDataOperation<TRequest>
  ): Promise<IOperationResult<TResponse>> {
    try {
      if (!operation?.dataverseRequest) {
        const errMsg = `${DataOperationErrorMessages.InvalidRequest}: ${DataOperationErrorMessages.MissingDataverseRequest}`;
        Log.trackEvent('DataverseDataOperation.ExecuteInvalidRequest', {
          message: '[DataverseDataOperation] Invalid execute request',
          error: errMsg,
        });
        throw new Error(errMsg);
      }
      const response = await this._xrm.WebApi.execute<TRequest, TResponse>(operation as TRequest);
      return this._createSuccessResult<TResponse>(response);
    } catch (error) {
      Log.trackEvent('DataverseDataOperation.ExecuteFailed', {
        message: '[DataverseDataOperation] Failed to execute operation',
        error,
      });
      return createErrorResponse<TResponse>(error, DataOperationErrorMessages.ExecuteFailed);
    }
  }

  /**
   * Returns the database references for Dataverse, grouped by environment/database.
   * These come from the launch app response via runtime metadata client.
   */
  public async getDatabaseReferences(): Promise<DatabaseReferences> {
    if (this._databaseReferences) {
      return this._databaseReferences;
    }

    // Get database references from runtime metadata (launch app response)
    // This is the authoritative source containing the complete linkedEnvironmentMetadata
    const runtimeDatabaseReferences = await this._loadDatabaseReferencesFromRuntime();
    if (runtimeDatabaseReferences && Object.keys(runtimeDatabaseReferences).length > 0) {
      this._databaseReferences = runtimeDatabaseReferences;
      return this._databaseReferences;
    }

    throw new PowerDataRuntimeError(
      ErrorCodes.DataSourceNotFound,
      'Failed to load Dataverse database references from runtime.'
    );
  }

  /**
   * Loads database references from runtime metadata client (launch app response).
   */
  private async _loadDatabaseReferencesFromRuntime(): Promise<DatabaseReferences | undefined> {
    try {
      const metadataClient = await this._getMetadataClient();

      // Get CDS data source configs from runtime metadata
      const response = await metadataClient.getAppDataSourceConfigsAsync();

      if (!response.success || !response.data) {
        return undefined;
      }

      const cdsDataSources = Object.values(response.data);
      if (cdsDataSources.length === 0) {
        return undefined;
      }

      // Build database references from runtime CDS data source configs
      const databaseReferences: DatabaseReferences = {};

      for (const cdsDataSource of cdsDataSources) {
        // Type assertion for CDS data source config
        const cdsConfig = cdsDataSource as {
          runtimeUrl: string;
          entitySetName: string;
          logicalName: string;
          version?: string;
        };

        // Extract instance URL and other metadata from runtime URL
        const instanceUrl = this._extractInstanceUrlFromRuntimeUrl(cdsConfig.runtimeUrl);

        // Use a standard environment name for CDS
        const envName = 'default.cds';

        if (!databaseReferences[envName]) {
          databaseReferences[envName] = {
            databaseDetails: {
              referenceType: 'Environmental',
              environmentName: envName,
              overrideValues: {
                status: 'NotSpecified',
                environmentVariableName: '',
              },
              linkedEnvironmentMetadata: {
                resourceId: '', // This would be available in the full app info
                friendlyName: '',
                uniqueName: '',
                domainName: '',
                version: cdsConfig.version || '9.2',
                instanceUrl,
                instanceApiUrl: cdsConfig.runtimeUrl,
                baseLanguage: 1033,
                instanceState: 'Ready',
                createdTime: '',
                platformSku: '',
              },
            },
            dataSources: {},
          };
        }

        // Add the data source
        const dataSourceName = cdsConfig.entitySetName || cdsConfig.logicalName;
        databaseReferences[envName].dataSources[dataSourceName] = {
          entitySetName: cdsConfig.entitySetName,
          logicalName: cdsConfig.logicalName,
          isHidden: false,
        };
      }

      return databaseReferences;
    } catch (error) {
      // Info-level logging for tracing errors loading from runtime
      Log.trackEvent('DataverseDataOperation.FailedToLoadDatabaseReferences', {
        message: '[DataverseDataOperation] Failed to load database references from runtime',
        error,
      });
      // Silently fail and return undefined if there's any error loading from runtime
      return undefined;
    }
  }

  private _extractInstanceUrlFromRuntimeUrl(runtimeUrl: string): string {
    try {
      // Runtime URL format: https://org.crm.dynamics.com/api/data/v9.2/
      // Extract: https://org.crm.dynamics.com
      // Using a simpler approach to avoid URL import issues
      const matches = runtimeUrl.match(/^(https?:\/\/[^\/]+)/);
      return matches ? matches[1] : runtimeUrl;
    } catch (error) {
      Log.trackEvent('DataverseDataOperation.FailedToExtractInstanceUrl', {
        message: '[DataverseDataOperation] Failed to extract instance URL from runtime URL',
        error,
      });
      // Fallback to original URL on error
      return runtimeUrl;
    }
  }

  /**
   * Validates operation parameters
   * @param params - The parameters to validate
   * @throws Error if validation fails
   */
  private _validateParams(params: Record<string, unknown>): void {
    for (const [key, value] of Object.entries(params)) {
      if (!value) {
        throw new Error(`${DataOperationErrorMessages.InvalidOperationParameters}: ${key} is required`);
      }
      if (!this._dataverseDataSourceService) {
        throw new PowerDataRuntimeError(ErrorCodes.DataClientInitFailed);
      }
    }
  }

  /**
   * Creates a success result object
   * @param data - The response data
   * @param totalCount - Optional total count for multiple record operations
   * @returns IDataOperationResult with success status
   */
  private _createSuccessResult<TResponse>(data: TResponse, totalCount?: number): IOperationResult<TResponse> {
    return {
      success: true,
      data,
    };
  }

  /**
   * Helper to check if XRM context is present and valid
   */
  private _hasCrm(): boolean {
    return !!(this._xrm && this._xrm.WebApi && typeof this._xrm.WebApi.createRecord === 'function');
  }

  /**
   * Helper to get a native data client and database reference
   */
  private async _getDataClient() {
    const dataClient = await this._clientProvider.getDataClientAsync();
    if (!dataClient) {
      Log.trackEvent('DataverseDataOperation.DataClientNotAvailable', {
        message: '[DataverseDataOperation] Data client is not available',
      });
      throw new PowerDataRuntimeError(ErrorCodes.DataClientNotAvailable, 'Data client is not available.');
    }
    return dataClient;
  }

  /**
   * Gets the metadata client instance
   */
  private async _getMetadataClient(): Promise<IRuntimeMetadataClient> {
    const metadataClient = await this._clientProvider.getMetadataClientAsync();
    if (!metadataClient) {
      Log.trackEvent('DataverseDataOperation.MetadataClientNotAvailable', {
        message: '[DataverseDataOperation] Metadata client is not available',
      });
      throw new PowerDataRuntimeError(ErrorCodes.MetadataClientNotAvailable);
    }
    return metadataClient;
  }

  /**
   * Template method for connector-style CRUD operations to reduce duplication.
   * Handles client, dataSourceInfo, requestUrl, and error handling.
   */
  private async _executeNativeDataverseOperation<TRequest, TResponse>(
    tableName: string,
    buildUrl: (dataSourceInfo: DataverseDataSourceInfo, tblName: string) => string,
    operation: (
      dataClient: IRuntimeDataClient,
      requestUrl: string,
      dataSourceInfo: DataverseDataSourceInfo
    ) => Promise<IOperationResult<TResponse>>,
    errorMessage: string
  ): Promise<IOperationResult<TResponse>> {
    try {
      const dataClient = await this._getDataClient();
      const dataSourceInfo = await this._getDataverseDataSourceInfo(tableName);
      const requestUrl = buildUrl(dataSourceInfo, tableName);
      return operation(dataClient as IRuntimeDataClient, requestUrl, dataSourceInfo);
    } catch (error) {
      return createErrorResponse<TResponse>(error, errorMessage);
    }
  }

  /**
   * Helper to get the Dataverse datasourceinfo from databaseReferences
   */
  private async _getDataverseDataSourceInfo(tableName: string): Promise<DataverseDataSourceInfo> {
    try {
      const dbRefs = await this.getDatabaseReferences();
      // Find the environment/database that contains this table
      for (const dbKey of Object.keys(dbRefs)) {
        const db = dbRefs[dbKey];
        if (db.dataSources[tableName]) {
          const ds = db.dataSources[tableName];
          return {
            datasetName: db.databaseDetails?.environmentName,
            referenceType: db.databaseDetails?.referenceType,
            linkedEnvironmentMetadata: db.databaseDetails?.linkedEnvironmentMetadata,
            entitySetName: ds?.entitySetName,
            logicalName: ds?.logicalName,
            isHidden: ds?.isHidden,
            tableId: ds?.logicalName,
            apis: {},
          };
        }
      }
      const notFoundMsg = `No Dataverse data source found for table: ${tableName}`;
      Log.trackEvent('DataverseDataOperation.DataSourceNotFound', {
        message: notFoundMsg,
        tableName,
      });
      throw new PowerDataRuntimeError(ErrorCodes.DataSourceNotFound, notFoundMsg);
    } catch (error) {
      Log.trackEvent('DataverseDataOperation.GetDataSourceInfoFailed', {
        message: '[DataverseDataOperation] Failed to get Dataverse data source info',
        tableName,
        error,
      });
      throw new PowerDataRuntimeError(
        ErrorCodes.DataSourceNotFound,
        `Failed to get Dataverse data source info for table '${tableName}': ${
          error instanceof Error ? error.message : String(error)
        }`
      );
    }
  }

  /**
   * Helper to construct the Dataverse API URL using instanceUrl if available, otherwise fallback to runtimeUrl.
   */
  private _getDataverseRequestUrl(
    dataSourceInfo: DataverseDataSourceInfo,
    tableName: string,
    urlPath: string = ''
  ): string {
    const instanceUrl = dataSourceInfo.linkedEnvironmentMetadata?.instanceUrl;
    if (!instanceUrl) {
      throw new PowerDataRuntimeError(
        ErrorCodes.DataClientInitFailed,
        'No instanceUrl found for Dataverse table.'
      );
    }

    // Ensure instanceUrl ends with a slash and construct proper URL
    const baseUrl = instanceUrl.endsWith('/') ? instanceUrl : `${instanceUrl}/`;
    return `${baseUrl}api/data/v9.0/${tableName}${urlPath}`;
  }
}

export interface ILinkedEnvironmentMetadata {
  resourceId: string;
  friendlyName: string;
  uniqueName: string;
  domainName: string;
  version: string;
  instanceUrl: string;
  instanceApiUrl: string;
  baseLanguage: number;
  instanceState: string;
  createdTime: string;
  platformSku: string;
}

export interface DataverseDataSourceInfo extends IDataSourceInfo {
  datasetName: string;
  referenceType?: string;
  linkedEnvironmentMetadata?: ILinkedEnvironmentMetadata;
  entitySetName?: string;
  logicalName?: string;
  isHidden?: boolean;
}

interface IDatabaseReference {
  databaseDetails: {
    referenceType: string;
    environmentName: string;
    overrideValues: {
      status: string;
      environmentVariableName: string;
    };
    linkedEnvironmentMetadata?: ILinkedEnvironmentMetadata;
  };
  dataSources: {
    [dataSourceName: string]: {
      entitySetName: string;
      logicalName: string;
      isHidden: boolean;
    };
  };
}

/**
 * Extracts the skip token from the next link URL.
 * @param nextLink - The @odata.nextLink URL containing the skip token
 * @returns The extracted skip token or undefined if not found.
 */
export function extractSkipToken(nextLink: string | undefined): string | undefined {
  if (!nextLink?.trim()) {
    return undefined;
  }

  const match = nextLink.match(/[\?&]\$?skiptoken=([^&#]+)/i);
  return match ? decodeURIComponent(match[1]) : undefined;
}

export type DatabaseReferences = { [key: string]: IDatabaseReference };
