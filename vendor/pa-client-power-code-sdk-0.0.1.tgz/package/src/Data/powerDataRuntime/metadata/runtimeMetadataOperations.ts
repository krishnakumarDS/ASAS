/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IRuntimeClientProvider } from '../common/types';
import {
  IConnectionApi,
  IConnectionReference,
  IMetadataOperations,
  IOperationContext,
} from '../common/types';
import { IOperationResult } from '../powerDataRuntime.Types';

/**
 * RuntimeMetadataOperations provides functionality for retrieving metadata
 * about connections and APIs.
 */
export class RuntimeMetadataOperations implements IMetadataOperations {
  // Static identifiers for services and actions
  // Used to identify specific services and actions within the PowerApps environment
  constructor(private readonly _clientProvider: IRuntimeClientProvider) {}

  public async getConnections(
    context?: IOperationContext
  ): Promise<IOperationResult<IConnectionReference[]>> {
    const client = await this._clientProvider.getMetadataClientAsync();
    const response = await client.getAppConnectionConfigsAsync(context);
    return {
      success: response.success,
      data: response.data ? [response.data] : [],
      error: response.error,
    };
  }

  public async getConnectionApis(
    _connectionId: string,
    context?: IOperationContext
  ): Promise<IOperationResult<IConnectionApi[]>> {
    const client = await this._clientProvider.getMetadataClientAsync();
    const response = await client.getAppDataSourceConfigsAsync(context);
    return {
      success: response.success,
      data: response.data ? [response.data as IConnectionApi] : [],
      error: response.error,
    };
  }
}
