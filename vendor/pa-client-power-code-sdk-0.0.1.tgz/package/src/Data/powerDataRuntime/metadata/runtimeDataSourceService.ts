/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { ErrorCodes, getErrorMessage, PowerDataRuntimeError } from '../error';
import { IPowerDataSourcesInfoProvider } from '../common/types';
import { DataSourcesInfo, IDataSourceInfo } from '../powerDataRuntime.Types';

/**
 * Error types specific to RuntimeDataSourceService
 */
export enum DataSourceServiceError {}

/**
 * RuntimeDataSourceService provides functionality for managing and retrieving
 * data source information.
 */
export class RuntimeDataSourceService {
  /**
   * Data source information
   */
  private _dataSourcesInfo: DataSourcesInfo;
  /**
   * Indicates whether the service has been initialized
   */
  private _isInitialized: boolean;

  /**
   * Creates a new instance of RuntimeDataSourceService
   */
  constructor(private _powerDataSourcesInfoProvider: IPowerDataSourcesInfoProvider) {
    this._dataSourcesInfo = {};
    this._isInitialized = false;
  }

  /**
   * Initializes the service by loading user data sources
   * @throws PowerDataRuntimeError if initialization fails
   */
  public async initialize(): Promise<void> {
    try {
      const userDataSources = await this._getUserDataSources();

      this._dataSourcesInfo = {};
      Object.keys(userDataSources).forEach((key) => {
        this._dataSourcesInfo[key] = userDataSources[key];
      });

      this._isInitialized = true;
    } catch (error) {
      throw new PowerDataRuntimeError(ErrorCodes.InitializationError, getErrorMessage(error));
    }
  }

  /**
   * Gets all user data sources
   * @returns Array of data source information
   * @throws PowerDataRuntimeError if service is not initialized
   */
  public async getUserDataSources(): Promise<DataSourcesInfo> {
    await this._ensureInitialized();

    return this._dataSourcesInfo;
  }

  /**
   * Gets information for a specific data source
   * @param dataSource - The ID of the data source
   * @returns Data source information
   * @throws PowerDataRuntimeError if data source is not found or service is not initialized
   */
  public async getDataSource(dataSource: string): Promise<IDataSourceInfo> {
    await this._ensureInitialized();

    const dataSourceInfo = this._dataSourcesInfo[dataSource];
    if (!dataSourceInfo) {
      throw new PowerDataRuntimeError(ErrorCodes.DataSourceNotFound, dataSource);
    }

    return dataSourceInfo;
  }

  /**
   * Checks if a data source exists
   * @param dataSourceId - The ID of the data source to check
   * @returns True if the data source exists, false otherwise
   * @throws PowerDataRuntimeError if service is not initialized
   */
  public async hasDataSource(dataSource: string): Promise<boolean> {
    await this._ensureInitialized();

    return dataSource in this._dataSourcesInfo;
  }

  /**
   * Ensures the service is initialized
   * @throws PowerDataRuntimeError if service is not initialized
   */
  private async _ensureInitialized(): Promise<void> {
    if (!this._isInitialized) {
      await this.initialize();
    }
  }

  /**
   * Gets user data sources from the provided data source schemas
   * @returns Promise resolving to array of data source information
   */
  private async _getUserDataSources(): Promise<DataSourcesInfo> {
    const dataSourcesInfo = await this._powerDataSourcesInfoProvider.getDataSourcesInfo();
    return Promise.resolve(dataSourcesInfo);
  }
}
