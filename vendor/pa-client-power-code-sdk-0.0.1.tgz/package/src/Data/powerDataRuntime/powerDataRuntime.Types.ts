/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IApiResponseInfo, IDataverseRequest } from './common/types';
import { PowerDataRuntimeHttpError } from './error';

// =========================================================
// Core PowerDataRuntime Types
// =========================================================

/**
 * Main PowerDataRuntime interface providing access to data operations
 */
export interface IPowerDataRuntime {
  /** Access to data operations */
  Data: IDataOperations;
}

// =========================================================
// Data Operations
// =========================================================

/**
 * Interface for performing CRUD operations on data sources
 */
export interface IDataOperations {
  /**
   * Creates a new record in the specified data source
   */
  createRecordAsync<TRequest, TResponse>(
    tableName: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>>;

  /**
   * Updates an existing record in the specified data source
   */
  updateRecordAsync<TRequest, TResponse>(
    tableName: string,
    id: string,
    data: TRequest
  ): Promise<IOperationResult<TResponse>>;

  /**
   * Deletes a record from the specified data source
   */
  deleteRecordAsync(tableName: string, id: string): Promise<IOperationResult<void>>;

  /**
   * Retrieves a record from the specified data source
   */
  retrieveRecordAsync<TResponse>(
    tableName: string,
    id: string,
    options?: IOperationOptions
  ): Promise<IOperationResult<TResponse>>;

  /**
   * Retrieves records from the specified data source
   */
  retrieveMultipleRecordsAsync<TResponse>(
    tableName: string,
    options?: IOperationOptions
  ): Promise<IOperationResult<TResponse[]>>;

  /**
   * Executes the provided operation on the specified data source.
   */
  executeAsync<TRequest, TResponse>(
    operation: IDataOperation<TRequest>
  ): Promise<IOperationResult<TResponse>>;
}

// =========================================================
// Type Definitions
// =========================================================

/**
 * Type definition for data source configuration
 */
export type DataSourcesInfo = Record<string, IDataSourceInfo>;

/**
 * Interface for data source info
 */
export interface IDataSourceInfo {
  /** Table identifier */
  tableId: string;
  /** Optional version information */
  version?: string;
  /** Optional primary key field */
  primaryKey?: string;
  /** Optional data source type field */
  dataSourceType?: string;
  /** Available APIs for the data source */
  apis: {
    [key: string]: IApiDefinition;
  };
}

// Public interfaces for API definitions and connections
export interface IApiDefinition {
  /** API path */
  path: string;
  /** HTTP method (GET, POST, etc.) */
  method: string;
  /** Parameters */
  parameters: Array<{
    /** Parameter name */
    name: string;
    /** Parameter location (query, path, etc.) */
    in: string;
    /** Whether the parameter is required */
    required: boolean;
    /** Parameter type (string, number, etc.) */
    type: string;
  }>;
  /** Response information */
  responseInfo?: Record<string, IApiResponseInfo>;
}

/**
 * Interface for PowerOperationExecutor
 * This interface defines the method for executing operations
 */
export interface IPowerOperationExecutor {
  execute<T = string>(
    operationName: string,
    action: string,
    params: Array<string | number | boolean | object | undefined>
  ): Promise<IOperationResult<T>>;
}

/**
 * Base interface for operation options
 * The parameters must be defined as OData query parameters
 */
export interface IOperationOptions {
  maxPageSize?: number;
  select?: string[];
  filter?: string;
  orderBy?: string[];
  top?: number;
  skip?: number;
  count?: boolean;
  skipToken?: string;
}

/**
 * Base interface for operation results
 * @template T The type of data returned by the operation
 */
export interface IOperationResult<TResponse> {
  success: boolean;
  data: TResponse;
  error?: Error | PowerDataRuntimeHttpError;

  /**
   * Skip token to get the next page of results
   * @type {string}
   */
  skipToken?: string;
}

export function isOperationResult<TResponse>(
  result: IOperationResult<TResponse> | TResponse | unknown
): result is IOperationResult<TResponse> {
  return (result as IOperationResult<TResponse>)?.success !== undefined;
}

/**
 * Interface for custom data operations
 */
export interface IDataOperation<TRequest> {
  /** Dataverse-specific request details */
  dataverseRequest?: IDataverseRequest;
  /** Connector-specific operation details */
  connectorOperation?: IConnectorOperation<TRequest>;
}

/**
 * Interface for connector-specific operations
 */
export interface IConnectorOperation<TParameters> {
  /** Target table name */
  tableName: string;
  /** Operation name to execute */
  operationName: string;
  /** Optional operation parameters */
  parameters?: TParameters;
}
