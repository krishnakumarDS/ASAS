/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { Log } from '../telemetry/log';
import { ErrorMessages, UnknownErrorMessage } from './messages';
import { ErrorCodes } from './codes';

/**
 * Base error class for PowerDataRuntime operations
 */
export class PowerDataRuntimeError extends Error {
  /**
   * Creates an instance of PowerDataRuntimeError.
   * @param code - The error code associated with the error.
   * @param additionalInfo - Optional additional information to include in the error message.
   * @param messageOverride - Optional override for the default error message.
   */
  constructor(public readonly code: ErrorCodes, additionalInfo?: string, messageOverride?: string) {
    let message = messageOverride || ErrorMessages[code] || UnknownErrorMessage;
    if (additionalInfo) {
      message += `: ${additionalInfo}`;
    }
    super(message);
    this.name = 'PowerDataRuntimeError';
    Log.trackException(this);
  }
}

export interface PowerDataRuntimeHttpError {
  message: string;
  status?: number;
  requestId?: string;
  stack?: string;
}

export interface HttpErrorResponse {
  status?: number;
  headers?: {
    [key: string]: string;
  };
}
