/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { ErrorCodes } from './codes';

export const UnknownErrorMessage = 'An unknown error occurred';

export const ErrorMessages: { [key in ErrorCodes]?: string } = {
  // PowerDataRuntime specific errors
  [ErrorCodes.InitializationFailed]: 'Failed to initialize PowerDataRuntime',
  [ErrorCodes.InvalidXrmInfo]: 'Xrm info is required',
  [ErrorCodes.OperationsNotInitialized]: 'PowerDataRuntime is not initialized',

  // RuntimeDataSourceService specific errors
  [ErrorCodes.DataSourceNotFound]: 'Data source not found',
  [ErrorCodes.DuplicateDataSource]: 'Duplicate data source',
  [ErrorCodes.InitializationError]: 'Failed to initialize RuntimeDataSourceService',
  [ErrorCodes.InvalidDataSource]: 'Invalid data source',

  // PowerDataSourcesInfoProvider specific errors
  [ErrorCodes.DataSourcesInfoNotFound]:
    'DataSourcesInfo must be provided to initialize the singleton instance.',

  // DataClientProvider specific errors
  [ErrorCodes.DataClientInitFailed]: 'Failed to initialize PowerDataClient',
  [ErrorCodes.DataClientNotInitialized]: 'PowerDataClient is not initialized',
  [ErrorCodes.MetadataClientInitFailed]: 'Failed to initialize PowerMetadataClient',
  [ErrorCodes.MetadataClientNotInitialized]: 'PowerMetadataClient is not initialized',

  // DataOperation specific errors
  [ErrorCodes.ClientProviderNotAvailable]: 'Client provider is not available',
  [ErrorCodes.ConnectionReferenceNotFound]: 'Connection reference not found',
  [ErrorCodes.DataClientNotAvailable]: 'PowerDataClient is not available',
  [ErrorCodes.DataSourceServiceNotAvailable]: 'Data source service is not available',
  [ErrorCodes.MetadataClientNotAvailable]: 'PowerMetadataClient is not available',

  // MetadataClient specific errors
  [ErrorCodes.ConnectionConfigFetchFailed]: 'Failed to fetch connection configurations',
  [ErrorCodes.DataSourceConfigFetchFailed]: 'Failed to fetch data source configurations',
  [ErrorCodes.InvalidMetadataResponse]: 'Invalid metadata response format',

  // RuntimeDataClient specific errors
  [ErrorCodes.TokenAcquisitionFailed]: 'Failed to acquire access token',
};

// The following error messages are returned to the client whenever a data
// operation fails. They are not explicitly logged to telemetry as exceptions,
// but are logged as part of the http pipeline.
export enum DataOperationErrorMessages {
  CreateFailed = 'Create operation failure',
  DeleteFailed = 'Delete operation failure',
  ExecuteFailed = 'Execute operation failure',
  InvalidOperationParameters = 'Invalid operation parameters',
  InvalidRequest = 'Invalid request',
  InvalidResponse = 'Invalid response format',
  MissingConnectorOperation = 'Connector operation is required',
  MissingDataverseRequest = 'Dataverse request is required',
  MissingOperationName = 'Operation name is required',
  MissingRequestBody = 'Request body is required',
  RetrieveFailed = 'Retrieve operation failure',
  RetrieveMultipleFailed = 'Retrieve multiple records operation failure',
  UpdateFailed = 'Update operation failure',
}
