/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IOperationResult, isOperationResult } from '../powerDataRuntime.Types';
import { HttpErrorResponse, PowerDataRuntimeError, PowerDataRuntimeHttpError } from './types';
import { UnknownErrorMessage } from './messages';
import { HeaderNames } from './constants';

/**
 * Retrieves the error message from an error object.
 * @param error - The error to handle, which can be an instance of Error or IOperationResult.
 * @returns The error message if applicable, or throws the error if it's a PowerDataRuntimeError.
 */
export function getErrorMessage(
  error: Error | IOperationResult<unknown> | object | PowerDataRuntimeHttpError | string | unknown | unknown[]
): string {
  if (typeof error === 'string') {
    return error;
  }
  if (error instanceof Error || error instanceof PowerDataRuntimeError) {
    return error.message || UnknownErrorMessage;
  }
  if (isOperationResult(error)) {
    return error.error?.message || UnknownErrorMessage;
  }
  if (typeof error === 'object') {
    return JSON.stringify(error);
  }
  return UnknownErrorMessage;
}

/**
 * Handles operation errors and creates an error OperationResult
 * @param error - The error object or OperationResult
 * @param friendlyMessage - A friendly message to include in the error
 */
export function createErrorResponse<T>(
  error: Error | PowerDataRuntimeError | IOperationResult<T> | unknown,
  friendlyMessage: string
): IOperationResult<T> {
  const message = getErrorMessage(error);

  let data;
  if (isOperationResult(error)) {
    data = error.data;
  }

  const errorData = new Error(`${friendlyMessage}: ${message}`);

  if (error instanceof Error) {
    errorData.stack = error.stack;
  }

  return {
    success: false,
    error: errorData,
    data: data as unknown as T,
  };
}

/**
 * Parses an error from the HTTP plugin and returns a PowerDataRuntimeHttpError object.
 * @param error - The error to parse, which should be an array with a nested array.
 * @returns A PowerDataRuntimeHttpError object containing the message and response.
 */
export function parseHttpPluginError(error: unknown): PowerDataRuntimeHttpError {
  let message = UnknownErrorMessage;
  let response: HttpErrorResponse | undefined;

  if (Array.isArray(error)) {
    if (Array.isArray(error[0])) {
      message = (error[0][0] as string) || UnknownErrorMessage;
      response = error[0][2] as HttpErrorResponse;
    }
  }

  const status = response?.status as number;
  const requestId = response?.headers?.[HeaderNames.RequestId] as string;

  return {
    message,
    status,
    requestId,
  };
}
