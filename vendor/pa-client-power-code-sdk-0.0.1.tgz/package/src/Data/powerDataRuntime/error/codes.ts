/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

/**
 * Error types specific to DataRuntime
 */
export enum ErrorCodes {
  // PowerDataRuntime specific errors
  InitializationFailed = 'PDR_INIT_FAILED',
  InvalidXrmInfo = 'INVALID_XRM_INFO',
  OperationsNotInitialized = 'OPS_NOT_INITIALIZED',

  // RuntimeDataSourceService specific errors
  DataSourceNotFound = 'CONNECTION_NOT_FOUND',
  DuplicateDataSource = 'DUPLICATE_DATA_SOURCE',
  InitializationError = 'RDSS_INIT_ERROR',
  InvalidDataSource = 'INVALID_DATA_SOURCE',

  // PowerDataSourcesInfoProvider specific errors
  DataSourcesInfoNotFound = 'DATA_SOURCES_INFO_NOT_FOUND',

  // DataClientProvider specific errors
  DataClientInitFailed = 'DATA_CLIENT_INIT_FAILED',
  DataClientNotInitialized = 'DATA_CLIENT_NOT_INITIALIZED',
  MetadataClientInitFailed = 'METADATA_CLIENT_INIT_FAILED',
  MetadataClientNotInitialized = 'METADATA_CLIENT_NOT_INITIALIZED',

  // DataOperation specific errors
  ClientProviderNotAvailable = 'CLIENT_PROVIDER_NOT_AVAILABLE',
  ConnectionReferenceNotFound = 'CONNECTION_REFERENCE_NOT_FOUND',
  DataClientNotAvailable = 'DATA_CLIENT_NOT_AVAILABLE',
  DataSourceServiceNotAvailable = 'DATA_SOURCE_SERVICE_NOT_AVAILABLE',
  MetadataClientNotAvailable = 'METADATA_CLIENT_NOT_AVAILABLE',

  // MetadataClient specific errors
  ConnectionConfigFetchFailed = 'CONNECTION_CONFIG_FETCH_FAILED',
  DataSourceConfigFetchFailed = 'DATA_SOURCE_CONFIG_FETCH_FAILED',
  InvalidMetadataResponse = 'INVALID_METADATA_RESPONSE',

  // RuntimeDataClient specific errors
  TokenAcquisitionFailed = 'TOKEN_ACQUISITION_FAILED',
}
