/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IConnectionApi, IConnectionReference, IRuntimeMetadataClient } from '../common/types';
import { ErrorCodes, getErrorMessage, PowerDataRuntimeError } from '../error';
import { IOperationResult, IPowerOperationExecutor } from '../powerDataRuntime.Types';

/**
 * Interface for metadata operation configuration
 */
interface IMetadataOperationConfig {
  service: string;
  action: string;
  params?: unknown;
}

/**
 * RuntimeMetadataClient handles metadata operations through PowerOperationExecutor
 */
export class RuntimeMetadataClient implements IRuntimeMetadataClient {
  // Static identifiers for services and actions
  // Used to identify specific services and actions within the PowerApps environment
  // These identifiers are used to execute operations through the PowerOperationExecutor
  // The services provide the functionality for the operations
  private static readonly SERVICES = {
    powerAppsClient: 'AppPowerAppsClientPlugin',
  };

  // The actions define the specific operations to be performed
  private static readonly ACTIONS = {
    getConnectionConfigs: 'loadAppConnectionsAsync_v2',
    getDataSourceConfigs: 'getAppCdsDataSourceConfigsAsync',
  };

  // Private member for the PowerOperationExecutor
  // The PowerOperationExecutor is used to execute operations on the clients
  constructor(private readonly _powerOperationExecutor: IPowerOperationExecutor) {}

  /**
   * Creates a new instance of RuntimeMetadataClient
   * @param powerOperationExecutor - The powerOperationExecutor instance
   * @returns Promise resolving to IRuntimeMetadataClient
   */
  public static createInstanceAsync(
    powerOperationExecutor: IPowerOperationExecutor
  ): Promise<RuntimeMetadataClient> {
    return Promise.resolve(new RuntimeMetadataClient(powerOperationExecutor));
  }

  /**
   * Fetches app connection configurations
   * @returns Promise resolving to connection reference details
   * @throws Error if the operation fails
   */
  public async getAppConnectionConfigsAsync(): Promise<IOperationResult<IConnectionReference>> {
    try {
      const config: IMetadataOperationConfig = {
        service: RuntimeMetadataClient.SERVICES.powerAppsClient,
        action: RuntimeMetadataClient.ACTIONS.getConnectionConfigs,
        params: [],
      };

      const result = await this._executeOperation<IConnectionReference>(config);
      return { success: true, data: result };
    } catch (error) {
      throw new PowerDataRuntimeError(ErrorCodes.ConnectionConfigFetchFailed, getErrorMessage(error));
    }
  }

  /**
   * Fetches app data source configurations
   * @returns Promise resolving to connection reference details
   * @throws Error if the operation fails
   */
  public async getAppDataSourceConfigsAsync(): Promise<IOperationResult<IConnectionApi>> {
    try {
      const config: IMetadataOperationConfig = {
        service: RuntimeMetadataClient.SERVICES.powerAppsClient,
        action: RuntimeMetadataClient.ACTIONS.getDataSourceConfigs,
        params: [],
      };

      const result = await this._executeOperation<IConnectionApi>(config);
      return { success: true, data: result };
    } catch (error) {
      throw new PowerDataRuntimeError(ErrorCodes.DataSourceConfigFetchFailed, getErrorMessage(error));
    }
  }

  /**
   * Executes a metadata operation with the given configuration
   * @param config - The operation configuration
   * @returns Promise resolving to the operation result
   * @throws Error if the operation fails
   */
  private async _executeOperation<T>(config: IMetadataOperationConfig): Promise<T> {
    try {
      const result = await this._powerOperationExecutor.execute(
        config.service,
        config.action,
        (config.params as Array<string | number | boolean | object>) || []
      );

      // Convert the keys of the result to lowercase
      const lowerCaseResult = Object.keys(result.data).reduce((acc, key) => {
        acc[key.toLowerCase()] = ((result.data as unknown as Record<string, unknown>) ?? {})[key];
        return acc;
      }, {} as Record<string, unknown>);

      return lowerCaseResult as T;
    } catch {
      throw new PowerDataRuntimeError(ErrorCodes.InvalidMetadataResponse);
    }
  }
}
