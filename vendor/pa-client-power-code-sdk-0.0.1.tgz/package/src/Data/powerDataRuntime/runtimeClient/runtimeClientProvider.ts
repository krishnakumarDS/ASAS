/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { IRuntimeClientProvider, IRuntimeDataClient, IRuntimeMetadataClient } from '../common/types';
import { IPowerOperationExecutor } from '../powerDataRuntime.Types';
import { RuntimeDataClient } from './runtimeDataClient';
import { RuntimeMetadataClient } from './runtimeMetadataClient';
import { ErrorCodes, getErrorMessage, PowerDataRuntimeError } from '../error';

/**
 * RuntimeClientProvider manages the lifecycle of runtime clients for data and metadata operations.
 * Implements a lazy initialization pattern for clients and ensures proper error handling.
 */
export class RuntimeClientProvider implements IRuntimeClientProvider {
  // Private members for data and metadata clients
  // The data client is responsible for handling data operations
  private _dataClient: IRuntimeDataClient | undefined;

  // The metadata client is responsible for handling metadata operations
  private _metadataClient: IRuntimeMetadataClient | undefined;

  // The operation executor is used to execute operations on the clients
  // It is an instance of IPowerOperationExecutor, which provides the necessary methods for executing operations
  private readonly _operationExecutor: IPowerOperationExecutor;

  // Constructor for RuntimeClientProvider
  // Accepts an optional IPowerOperationExecutor instance for executing operations
  // If not provided, uses the default PowerOperationExecutor instance
  constructor(powerOperationExecutor: IPowerOperationExecutor) {
    this._operationExecutor = powerOperationExecutor;
  }

  /**
   * Gets or initializes the data client
   * @throws Error if client initialization fails
   * @returns Promise resolving to IRuntimeDataClient
   */
  public async getDataClientAsync(): Promise<IRuntimeDataClient> {
    try {
      if (!this._dataClient) {
        this._dataClient = await this._initializeDataClient();
      }

      if (!this._dataClient) {
        throw new PowerDataRuntimeError(ErrorCodes.DataClientNotInitialized);
      }

      return this._dataClient;
    } catch (error) {
      throw new PowerDataRuntimeError(ErrorCodes.DataClientInitFailed, getErrorMessage(error));
    }
  }

  /**
   * Gets or initializes the metadata client
   * @throws Error if client initialization fails
   * @returns Promise resolving to IRuntimeMetadataClient
   */
  public async getMetadataClientAsync(): Promise<IRuntimeMetadataClient> {
    try {
      if (!this._metadataClient) {
        this._metadataClient = await this._initializeMetadataClient();
      }

      if (!this._metadataClient) {
        throw new PowerDataRuntimeError(ErrorCodes.MetadataClientNotInitialized);
      }

      return this._metadataClient;
    } catch (error) {
      throw new PowerDataRuntimeError(ErrorCodes.MetadataClientInitFailed, getErrorMessage(error));
    }
  }

  /**
   * Initializes the data client
   * @returns Promise resolving to IRuntimeDataClient
   */
  private async _initializeDataClient(): Promise<IRuntimeDataClient> {
    return RuntimeDataClient.createInstanceAsync(this._operationExecutor);
  }

  /**
   * Initializes the metadata client
   * @returns Promise resolving to IRuntimeMetadataClient
   */
  private async _initializeMetadataClient(): Promise<IRuntimeMetadataClient> {
    return RuntimeMetadataClient.createInstanceAsync(this._operationExecutor);
  }

  /**
   * Resets both clients, forcing re-initialization on next use
   * Useful for testing or recovering from error states
   */
  public reset(): void {
    this._dataClient = undefined;
    this._metadataClient = undefined;
  }
}
