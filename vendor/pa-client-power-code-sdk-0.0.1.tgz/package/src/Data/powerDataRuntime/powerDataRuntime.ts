/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import {
  IMetadataOperations,
  IPowerDataSourcesInfoProvider,
  IRuntimeClientProvider,
  IXrmContext,
} from './common/types';
import { RuntimeDataOperations } from './data/runtimeDataOperations';
import { RuntimeMetadataOperations } from './metadata/runtimeMetadataOperations';
import { RuntimeClientProvider } from './runtimeClient/runtimeClientProvider';
import { IClientConfig } from './common/types';
import { DataverseDataOperation } from './data/dataverseDataOperation';
import { ConnectorDataOperation } from './data/connectorDataOperation';
import { RuntimeDataSourceService } from './metadata/runtimeDataSourceService';
import { IDataOperations, IPowerDataRuntime, IPowerOperationExecutor } from './powerDataRuntime.Types';
import { Log } from './telemetry/log';
import { ErrorCodes, getErrorMessage, PowerDataRuntimeError } from './error';

/**
 * Interface for PowerDataRuntime initialization parameters
 */
export interface IPowerDataRuntimeInitParams {
  powerDataSourcesInfoProvider: IPowerDataSourcesInfoProvider;
  powerOperationExecutor: IPowerOperationExecutor;
  xrm: IXrmContext;
  clientConfig?: IClientConfig;
}

/**
 * PowerDataRuntime provides a unified interface for data and metadata operations
 * in the Power runtime environment.
 */
export class PowerDataRuntime implements IPowerDataRuntime {
  private readonly _clientProvider: IRuntimeClientProvider;
  private readonly _dataSourceService: RuntimeDataSourceService;
  private readonly _xrm: IXrmContext;
  private _dataOperations?: IDataOperations;
  private _metadataOperations?: IMetadataOperations;
  private _isInitialized: boolean;

  /**
   * Creates a new instance of PowerDataRuntime
   * @param params - Initialization parameters
   * @throws DataRuntimeError if initialization fails
   */
  constructor(params: IPowerDataRuntimeInitParams) {
    try {
      this._validateInitParams(params);

      // Initialize the telemetry logger
      Log.createInstance(params.powerOperationExecutor);

      this._clientProvider = new RuntimeClientProvider(params.powerOperationExecutor);
      this._dataSourceService = new RuntimeDataSourceService(params.powerDataSourcesInfoProvider);
      this._xrm = params.xrm;
      this._isInitialized = false;
      this._initialize();
    } catch (error) {
      if (error instanceof Error) {
        Log.trackException(error);
      }
      throw error;
    }
  }

  /**
   * Gets the Data operations interface
   * @throws PowerDataRuntimeError if operations are not initialized
   */
  public get Data(): IDataOperations {
    this._ensureInitialized();
    if (!this._dataOperations) {
      this._dataOperations = this._createDataOperations();
    }
    return this._dataOperations;
  }

  /**
   * Gets the Metadata operations interface
   * @throws PowerDataRuntimeError if operations are not initialized
   */
  public get Metadata(): IMetadataOperations {
    this._ensureInitialized();
    if (!this._metadataOperations) {
      this._metadataOperations = this._createMetadataOperations();
    }
    return this._metadataOperations;
  }

  /**
   * Validates initialization parameters
   * @param params - Parameters to validate
   * @throws PowerDataRuntimeError if validation fails
   */
  private _validateInitParams(params: IPowerDataRuntimeInitParams): void {
    if (!params.xrm) {
      throw new PowerDataRuntimeError(ErrorCodes.InvalidXrmInfo);
    }
  }

  /**
   * Ensures the PowerDataRuntime is initialized
   * @throws PowerDataRuntimeError if not initialized
   */
  private _ensureInitialized(): void {
    if (!this._isInitialized) {
      throw new PowerDataRuntimeError(ErrorCodes.OperationsNotInitialized);
    }
  }

  /**
   * Initializes the PowerDataRuntime components
   * @throws PowerDataRuntimeError if initialization fails
   */
  private _initialize(): void {
    try {
      this._dataOperations = this._createDataOperations();
      this._metadataOperations = this._createMetadataOperations();
      this._isInitialized = true;
    } catch (error) {
      throw new PowerDataRuntimeError(ErrorCodes.InitializationFailed, getErrorMessage(error));
    }
  }

  /**
   * Creates a new instance of DataOperations
   */
  private _createDataOperations<TRequest, TResponse>(): IDataOperations {
    const dataverseOperation = new DataverseDataOperation(
      this._xrm,
      this._dataSourceService,
      this._clientProvider
    );
    const connectorOperation = new ConnectorDataOperation(this._clientProvider, this._dataSourceService);
    return new RuntimeDataOperations(dataverseOperation, connectorOperation, this._dataSourceService);
  }

  /**
   * Creates a new instance of MetadataOperations
   */
  private _createMetadataOperations(): IMetadataOperations {
    return new RuntimeMetadataOperations(this._clientProvider);
  }
}
