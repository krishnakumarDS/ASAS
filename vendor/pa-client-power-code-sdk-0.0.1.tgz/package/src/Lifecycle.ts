/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { executePlugin, initializePlugins } from './PluginCommon';
import { setupLogger } from './LoggerManager';
import type { Logger } from './Logger.types';
import { getPerformanceData } from './Performance';

let initialized = false;

export async function initialize(options?: { logger?: Logger }): Promise<void> {
  if (initialized) {
    return;
  }
  initialized = true;

  await initializePlugins();

  if (options?.logger) {
    setupLogger(options.logger);
  }

  executePlugin('AppLifecycle', 'notifyAppIndexLoaded');
  executePlugin('AppLifecycle', 'notifyAppLoaded', [getAppLoadedPerformanceData(), {}]);
}

export function getAppLoadedPerformanceData(): string {
  try {
    const perfData = getPerformanceData();
    return JSON.stringify(perfData);
  } catch (e) {
    return '{}';
  }
}
