/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

export function getPerformanceData(): object {
  const performanceApi = new PerformanceApi();
  const perfData: Record<string, unknown> = {
    appTimeOrigin: performanceApi.timeOrigin,
  };

  const navigationTimingEntries = performanceApi.getEntriesByType('navigation');
  const navigationTiming = navigationTimingEntries[0] as PerformanceNavigationTiming | undefined;
  if (navigationTiming) {
    perfData.appNavigateType = navigationTiming.type;
    perfData.appNavigationStart = navigationTiming.startTime;
    perfData.appNavigationDuration = navigationTiming.duration;
    perfData.appEncodedBodySize = navigationTiming.encodedBodySize;
    perfData.appNextHopProtocol = navigationTiming.nextHopProtocol;
    perfData.appDomainLookupStart = navigationTiming.domainLookupStart;
    perfData.appDomainLookupEnd = navigationTiming.domainLookupEnd;
    perfData.appConnectStart = navigationTiming.connectStart;
    perfData.appConnectEnd = navigationTiming.connectEnd;
    perfData.appSecureConnectionStart = navigationTiming.secureConnectionStart;
    perfData.appFetchStart = navigationTiming.fetchStart;
    perfData.appRequestStart = navigationTiming.requestStart;
    perfData.appResponseStart = navigationTiming.responseStart;
    perfData.appResponseEnd = navigationTiming.responseEnd;
    perfData.appLoadEventEnd = navigationTiming.loadEventEnd;
    perfData.appDomInteractive = navigationTiming.domInteractive;
    perfData.appDomContentLoadedEventStart = navigationTiming.domContentLoadedEventStart;
  }

  return perfData;
}

class PerformanceApi {
  private _performance: Performance;
  constructor(targetWindow: Window = window) {
    this._performance = targetWindow.performance;
  }

  get timeOrigin(): number | undefined {
    return this._performance?.timeOrigin;
  }

  public getEntriesByType(type: string): PerformanceEntryList {
    if (!this._performance?.getEntriesByType) {
      return [];
    }
    return this._performance.getEntriesByType(type);
  }
}
