/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { executePluginAsync } from '../PluginCommon';
import type { CompatibilityCheckerResult, MessageReceiver, SendMessagePlugin } from './MessageReceiver.Types';
import { IncompatibleMessageReceiver } from './IncompatibleMessageReceiver';
import { CompatibleMessageReceiver } from './CompatibleMessageReceiver';

export class SendMessage implements SendMessagePlugin {
  public static createInstanceAsync(): Promise<SendMessagePlugin> {
    return Promise.resolve(new SendMessage());
  }

  constructor() {}

  public async getMessageReceiverAsync(
    receiverName: string,
    isCompatibleChecker: (versionInfo: string) => CompatibilityCheckerResult
  ): Promise<MessageReceiver> {
    const versionInfo = await this._getVersionInfo(receiverName);
    if (versionInfo) {
      const compatibilityCheckerResult = isCompatibleChecker(versionInfo);
      if (compatibilityCheckerResult.isCompatible === false) {
        return new IncompatibleMessageReceiver(
          versionInfo,
          compatibilityCheckerResult.incompatibilityDescription || ''
        );
      } else {
        return new CompatibleMessageReceiver(receiverName, versionInfo);
      }
    } else {
      return new IncompatibleMessageReceiver(undefined, `No receiver ${receiverName} registered.`);
    }
  }

  private async _getVersionInfo(receiverName: string): Promise<string> {
    const result = await executePluginAsync('SendMessagePlugin', 'getVersionInfo', [receiverName]);
    return result as string;
  }
}
