/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

export class IncompatibleMessageReceiver {
  public readonly isCompatible = false;

  public constructor(public versionInfo: string | undefined, public incompatibilityDescription: string) {}
}
