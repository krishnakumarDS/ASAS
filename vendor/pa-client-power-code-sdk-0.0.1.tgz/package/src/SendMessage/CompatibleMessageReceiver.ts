/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

import { executePluginAsync } from '../PluginCommon';
import { SendMessageOperation } from './SendMessageOperation';
import type { CompatibleReceiverMessage } from './MessageReceiver.Types';
import { generate128BitUUID } from './Utils';

export class CompatibleMessageReceiver {
  public readonly isCompatible = true;

  public constructor(private _receiverName: string, public versionInfo: string | undefined) {}

  public async sendMessage(message: string, onMessageReceived: ((message: string) => void) | undefined) {
    let resolveOperationPromise: (message: string) => void;
    let rejectOperationPromise: (error: Error) => void;

    const operationPromise = new Promise<string>((resolve, reject) => {
      resolveOperationPromise = resolve;
      rejectOperationPromise = reject;
    });
    const correlationId = generate128BitUUID();

    const handleMessage = (compatibleReceiverMessage: CompatibleReceiverMessage) => {
      try {
        // Ignore any update after the operation has completed, caller cannot receive additional results.
        if (sendMessageOperation.completed) {
          return;
        }

        if (compatibleReceiverMessage) {
          // If the message is an intermediate update then call the message handler, otherwise complete the operation.
          if (compatibleReceiverMessage.isUpdate) {
            if (sendMessageOperation.onMessageReceived) {
              try {
                sendMessageOperation.onMessageReceived(compatibleReceiverMessage.message);
              } catch (error) {
                sendMessageOperation.completed = true;
                rejectOperationPromise(error as Error);
              }
            } else {
              sendMessageOperation.completed = true;
              rejectOperationPromise(
                new Error(
                  `Native receiver expected a message handler, but no handler was supplied. Message: ${compatibleReceiverMessage.message}`
                )
              );
            }
          } else {
            // The callback is the final result, pass it back to the initial caller.
            sendMessageOperation.completed = true;
            resolveOperationPromise(compatibleReceiverMessage.message);
          }
          return;
        }
      } catch {
        // The response isn't parsable, continue to promise completion.
      }
      // The callback is the final result, pass it back to the initial caller
      sendMessageOperation.completed = true;
      resolveOperationPromise(compatibleReceiverMessage.message);
    };
    // Error handler to catch any errors during native execution.
    // When receiving an error forward it to the caller.
    const handleError = (error: Error) => {
      sendMessageOperation.completed = true;
      rejectOperationPromise(error);
    };
    // Create function for sending intermediate updates from the calling context.
    const sendUpdate = (updateMessage: string) => {
      if (sendMessageOperation.completed) {
        throw new Error('Tried to send update for completed operation.');
      }

      // Call executePluginAsync, but do not register for results.  Any results will be sent back to the original handlers.
      executePluginAsync('SendMessagePlugin', 'sendMessage', [
        this._receiverName,
        updateMessage,
        correlationId,
      ]);
    };
    // Call executePluginAsync to send the native message to react-native, and begin the request.
    const sendMessageOperation = new SendMessageOperation(operationPromise, sendUpdate);
    sendMessageOperation.onMessageReceived = onMessageReceived;
    try {
      const sendMessageResponse: CompatibleReceiverMessage = await executePluginAsync(
        'SendMessagePlugin',
        'sendMessage',
        [this._receiverName, message, correlationId]
      );
      handleMessage(sendMessageResponse);
    } catch (error) {
      handleError(error as Error);
    }
    // Synchronously return the operation to the caller.
    return sendMessageOperation;
  }
}
