/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

export class SendMessageOperation {
  /**
   * When completed is false onMessageReceived and sendUpdate will be visible.
   * When completed is true then these are hidden.
   */
  public completed = false;
  public onMessageReceived: ((message: string) => void) | undefined = undefined;
  public constructor(public resultPromise: Promise<string>, public sendUpdate: (update: string) => void) {}
}
