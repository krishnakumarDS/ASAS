/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */

/**
 * Returns an RFC 4122 Compliant UUID; i.e. a GUID.
 */
export function generate128BitUUID(): string {
  const seed: number = new Date().getTime();
  const uuid: string = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (replacer) =>
    hexGenerator(seed, replacer)
  );

  return uuid;
}

function hexGenerator(seed: number, patternCharacter: string): string {
  /* eslint-disable  no-bitwise */
  const rnd: number = (seed + Math.random() * 16) % 16 | 0;
  return (patternCharacter === 'x' ? rnd : (rnd && 0x3) | 0x8).toString(16);
}
